#' Estimation of missing value feature-based
#'
#'It returns to a matrix of data in which missing values are estimated. By this function, all Zero values are first replaced by NA values, which are then replaced by the lowest detected value on the column margin. This function is applicable in all sort of high-throughput experiments. In a metabolomics workflow, it is suggested for a targeted approach where variables (features) measured at specific mass to charge transition.
#'@param m An array or a matrix
#'@keywords Missing value estimation
#'@details empty entries are not allowed
#'@return A matrix with estimated missing value.
#'@examples
#' m<- data.frame(x1=c(50,NA,6,10,30),x2=c(2,8,NA,15,0))
#'
#'@export
emvf <-function(m){
  apply(m, 2, function (x) {
    x[x == 0] <- NA;
    x<-as.numeric(as.character(x))
    x[is.na(x)] = min(x[x >0], na.rm=TRUE)
    x
  }
  )
}
#'Estimation of missing value data-based
#'
#'It returns to a matrix of data in which missing values are estimated by the lowest detected value in the entire experiment. By this function, all NA values are replaced by Zero values, that of being ultimately replaced by the lowest value detected in the experiment. Ultimately, data matrix is transposed to restore original structure.
#'
#' @param m An array or a matrix
#' @keywords Missing value estimation
#' @details empty entries are not allowed
#' @return  A matrix with estimated missing value.
#'@examples
#' m<- data.frame(x1=c(50,NA,6,10,30),x2=c(2,8,NA,15,0))
#' @export
emvd<- function(m){
  t(apply (m, 1,function(x){
    x[is.na(x)] <- 0
    small <- min(length(x))
    x[x == 0] <- NA
    x[is.na(x)] <- small
    x
  }
  )
  )
}
#'
#'
#'
#'
#'
#'
#'Visualization of drift across batch normalization
#'
#'This function performs batch effect adjustment via three statistical models implemented in the \code{dbnorm}, namely two-stage procedure two-stage procedure model as described by \emph{Giordan (2013)} and/or empirical Bayes methods in two setting of parametric and non-parametric as described by \emph{Johnson et al.(2007)} and in \emph{sva} package by \emph{Leek et al.(2012)}. Meanwhile, the graphical inferences in the context of unsupervised learning algorithms create visual inspection to inform users about the spatial separation of the sample sets analyzed in the different analytical runs alongside the distribution of variables (features) in the raw and treated datasets. This function is suggested for less than \emph{2k} variables (features).\cr
#'install.packages (c("ggplot2", "NormalizeMets","ggfortify", "factoextra","MASS","ber"))\cr
#'source("https://bioconductor.org/biocLite.R")\cr
#'biocLite(c("pcaMethods","impute","sva","limma","genefilter"))
#'
#'@param f A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by \code{emvf} or \code{emvd}, functions implemented in the \bold{dbnorm} package. Input data must be normalized beforehand.
#'@return  Three datasets, adjusted by either of applied statistical algorithms prepared in \emph{csv} and together with series of plot such as \bold{PCA} plot and \bold{Scree plot} compiled into \emph{pdf} are saved in the working directory. \bold{RLA} plots are represented in the Viewer panel of \emph{rstudio}.
#'@keywords Visualization and across batch normalization
#'
#'@references M.Giordan (2013) \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}\cr
#'Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#'@examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'f<-data.frame(batch,y)
#'@export
Visdbnorm<- function(f){
com_p<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
com_n<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
colnames(f)[1]<-"Batch";
y<- ber(as.matrix(f[,-1]),as.factor(f[,1]));#two-stage regression
m_p<- data.frame(f[1],t(com_p));
m_n<- data.frame(f[1],t(com_n));
pdf("dbnorm_plots.pdf")
p<-prcomp(f[,-1],center=T,scale=T)
p.c<-prcomp(y,center=T,scale=T);
p.c_p<-prcomp(m_p[-1],center=T,scale=T);
p.c_n<-prcomp(m_n[-1],center=T,scale=T);
pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                  addEllipses=TRUE, ellipse.level=0.95)+
  labs(title ="PCA-raw");
pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
  labs(title ="PCA-ber-corrected");
pca.p<-fviz_pca_ind(p.c_p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
  labs(title ="PCA-combatParametric-corrected");
pca.n<-fviz_pca_ind(p.c_n,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
  labs(title ="PCA-combatNonparametric-corrected");

sp<- screeplot(p, type = "l", npcs = 10, main = " First 10 PCs_raw",ylim=c(0,100))
abline(h = 1, col="red", lty=5)
labs(title ="raw-data",x = "PC", y = "Variance")
legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
sp.cor<- screeplot(p.c, type = "l", npcs = 10, main = "First 10 PCs-ber")
abline(h = 1, col="red", lty=5)
labs(title ="ber-data",x = "PC", y = "Variance")
legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
sp.p<- screeplot(p.c_p, type = "l", npcs = 10, main = "First 10 10 PCs-ComBatParametric")
abline(h = 1, col="red", lty=5)
labs(title ="ComBat-Parametric",x = "PC", y = "Variance")
legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
sp.n<- screeplot(p.c_n, type = "l", npcs = 10, main = "First 10 PCs-ComBatNParametric")
abline(h = 1, col="red", lty=5)
labs(title ="ComBat-NonParametric",x = "PC", y = "Variance")
legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
g<-data.frame(f[1],y);
write.csv(g,file="mydata_ber_corrected.csv");
write.csv(m_p,file="mydata_ComBatParametric.csv")
write.csv(m_n,file="mydata_ComBatNonParametric.csv")
rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_raw")
rlp.c<-RlaPlots( y, f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_Ber")
rlp.p<-RlaPlots( m_p[-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ComBatParametric")
rlp.n<-RlaPlots( m_n[-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ComBatNonParametric")
par (mfrow=c(8,1))
print(sp)
print(sp.cor)
print(sp.p)
print(sp.n)
print(pca)
print(pca.c)
print(pca.p)
print(pca.n)
print(rlp)
print(rlp.c)
print(rlp.p)
print(rlp.n)
dev.off()
}
#'
#'
#'
#'
#'Adjusted coefficient of determination for a data normalized for across batch signal drift
#'
#'This function gives a quick notification about the performance of the statistical models implemented in the \code{dbnorm} package such as \emph{Giordan (2013)} and/or empirical Bayes methods in two setting of parametric and non-parametric as described by \emph{Johnson et al.(2007)} and in \emph{sva} package by \emph{Leek et al.(2012)}. It calculates adjusted coefficient of determination or \emph{Adjusted R-Squared} for each variable estimated in a regression model for its dependency to the batch level in the raw data and treated data via either of those models. Immediately, the performance of applied models are presented by two scores calculated based on the total degree of variability and maximum variability explained by the batch level for each variables. Which respectively notify the overall performance of a model and the consistency of model performance for all detected variables (features), facilitating quick comparison of the models for selecting one of those models, which is more appropriate to the data structure. This function is suggested for less than \emph{2k} features.\cr
#'install.packages (c("ggplot2", "NormalizeMets","ggfortify", "factoextra","MASS","ber"))\cr
#'source("https://bioconductor.org/biocLite.R")\cr
#'biocLite(c("pcaMethods","impute","sva","limma","genefilter"))
#'
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by \code{emvf} or \code{emvd}, functions implemented in \code{dbnorm} package. Input data must be normalized beforehand.
#'@return  A two columns matrix, for each applied model, consisting of the name of the variables (features) with the corresponding Adjusted R-squared value in \emph{csv} format saved in the working directory. In parallel, two distinct bar plots for the scores given to the total variability and maximum variability with respect to each treatment algorithm compiled into \emph{pdf} together with the corresponding exact value presented in the table and saved in \emph{csv}.
#'@keywords Adjusted R-squared
#'@references M.Giordan (2013) \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}\cr
#'Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#'
#'@examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#'@export
ACDdbnorm <- function(m){
colnames(m)[1]<-"Batch";
com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
com_n<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
y<- ber(as.matrix(m[,-1]),as.factor(m[,1]));#two-stage regression
g<-data.frame(m[,1],y);
pcom<-data.frame(m[1],t(com_p));
npcom<-data.frame(m[1],t(com_n));
corr <- sapply(2:ncol(m),function(i){
  fit <- lm(m[,i]~ as.factor(m[,1]))
  return( summary(fit)[["adj.r.squared"]])
});
corr.b<-sapply(2:ncol(g),function(i){
  fit.b <- lm(g[,i]~ as.factor(g[,1]))
  return( summary(fit.b)[["adj.r.squared"]])
})
corr.cp<-sapply(2:ncol(pcom),function(i){
  fit.cp <- lm(pcom[,i]~ as.factor(m[,1]))
  return( summary(fit.cp)[["adj.r.squared"]])
});

corr.ncp<-sapply(2:ncol(npcom),function(i){
  fit.ncp <- lm(npcom[,i]~ as.factor(m[,1]))
  return( summary(fit.ncp)[["adj.r.squared"]])
})
write.csv(y,file = "mydata_berCorrected.csv")
write.csv(pcom,file = "mydata_ParaComBatCorrected.csv")
write.csv(npcom,file = "mydata_NParaComBatCorrected.csv")
names(corr)<- names(m[-1])
write.csv(corr, file="Rawdata_adjRsquared.csv")
names(corr.b)<- names(m[-1])
write.csv(corr.b, file="berdata_adjRsquared.csv")
names(corr.cp)<- names(m[-1])
write.csv(corr.cp, file="ParaComBat_adjRsquared.csv")
names(corr.ncp)<- names(m[-1])
write.csv(corr.ncp, file="NParaComBatdata_adjRsquared.csv")
a1<- abs (corr [1:length(corr)])
a11<-sum(a1)
a12<-max(a1)
a2<- abs(corr.b[1:length(corr.b)])
a21<- sum(a2)
a22<-max(a2)
a3<- abs (corr.cp[1:length(corr.cp)])
a31<-sum(a3)
a32<-max(a3)
a4<-abs (corr.ncp[1:length(corr.ncp)])
a41<-sum(a4)
a42<-max(a4)
datf<-data.frame(Dataset=c("raw","npcom","pcom","ber"),SumadjRSq=c(a11,a41,a31,a21),
                 MaxdjRSq=c(a12,a42,a32,a22) );
write.csv(datf,file = "SCore_adjRSq.csv")

pdf("RSQSumMax_plot.pdf")
p<-ggplot(data=datf, aes(x=reorder(Dataset, -SumadjRSq), y=SumadjRSq, fill=Dataset)) +
  geom_bar(stat="identity",width= 1)+
  theme_classic()
p<-p + labs(x = "Dataset (RaW vs Model-corrected)")
p<-p + labs(y = "Sum of adj.r.squared")
p<- p + coord_flip()

pmaxim<-ggplot(data=datf, aes(x=reorder(Dataset, -MaxdjRSq), y=MaxdjRSq, fill=Dataset)) +
  geom_bar(stat="identity",width= 1)+
  theme_classic()
pmaxim<-pmaxim + labs(x = "Dataset (RaW vs Model-corrected)")
pmaxim<-pmaxim + labs(y = "Maximum adj.r.squared")
pmaxim<- pmaxim + coord_flip()
print(p)
print(pmaxim)
print(p)
dev.off()
}
#'
#'
#'Visualization of analytical heterogeneity on the profile of variables (features) in raw data
#'
#'This function informs you about the presence of across batch signal drift or batch effect in the raw data determined by the shifted \emph{probability density function} plots (\emph{pdf} plots) of variables (features) detected in an experiment.\cr
#'install.packages (c("ggplot2", "ggfortify", "factoextra"))
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#' @return Original dataset in \emph{csv} format together with the series of profile plot for the variables( features) in the sample sets analyzed in the entire experiment provided by the \bold{Scatter} plot,\bold{Violin} plot and \bold{Density} plot compiled into \emph{pdf}.\cr
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed beforehand.
#' @keywords raw data profile plot
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3),1))
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#' @export
profplotraw<- function (m)
{
  origibal <- (m)
  colnames(m)[1] <- "Batch"
  pdf("ProfilePlot_RawData.pdf")
  loop.vector <- 1:length(m[, -1])
  for (i in loop.vector) {
    x <- m[, i + 1]
    n <- median(m[, i + 1])
    std <- sd(m[, i + 1])
    par(mfrow = c(3, 1))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i +1],
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    dplot <- ggplot(m, aes(x = x, colour = as.factor(m[,1]))) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i +1]) +
      labs(x="Batch", caption = "(based on Raw_Data)") + theme_classic()
    p <- ggplot(m, aes(x = as.factor(m[, 1]), y = x)) +
      geom_violin(trim = FALSE,
                  fill = "gray", color = "black") +
      geom_jitter(shape = 19,position = position_dodge(1)) +
      labs(x="Batch",y="Normalized intensity", title = colnames(m)[i +1]) +
      geom_boxplot(width = 0.1)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}

#'Visualization of analytical heterogeneity on the profile of variables (features) in ber- corrected data
#'
#'\emph{profplotber} allows you to adjust the data for batch effect using two-stage procedure approach as describes by \emph{Giordan (2013)} and informs you about the presence of across batch signal drift or batch effect in the treated data determined by the shifted \emph{probability density function} plots (\emph{pdf} plots) of variables (features) detected in an experiment.\cr
#' install.packages (c("ggplot2","ggfortify", "factoextra","MASS","ber"))
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#' @return An adjusted dataset in \emph{csv} format together with the series of profile plot for the variables( features) in the sample sets analyzed in the entire experiment provided by the \bold{Scatter} plot,\bold{Violin} plot and \bold{Density} plot compiled into \emph{pdf}.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed beforehand.
#' @keywords ber correction and profile plot
#' @references M.Giordan (2013) \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3),1))
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#' @export
profplotber<- function (m){
  origibal <- (m)
  y <- ber(as.matrix(m[, -1]), as.factor(m[, 1]))
  g <- data.frame(data.frame(m[, 1], y))
  colnames(g)[1] <- "Batch"
  pdf("ProfilePlot_berCorrected.pdf")
  loop.vector <- 1:length(m[, -1])
  for (i in loop.vector) {
    x <- y[, i]
    xx <- g[, i + 1]
    n <- median(y[, i])
    std <- sd(y[, i])
    par(mfrow = c(3, 1))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i + 1],
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    dplot <- ggplot(g, aes(x = xx, colour = as.factor(g[,1]))) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i + 1]) +
      labs(x= "Normalized intensity", caption = "(based on ber-Corrected)") +
      theme_classic()
    p <- ggplot(g, aes(x = as.factor(g[, 1]), y = xx)) +
      geom_violin(trim = FALSE, fill = "gray", color = "black") +
      geom_jitter(shape = 19, position = position_dodge(1)) +
      labs(x= "Batch", y= "Normalized intensity", title = colnames(g)[i + 1]) +
      geom_boxplot(width = 0.1)
    write.csv(m, file = "original.csv")
    write.csv(g, file = "ber_corrected_data.csv")
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#'Visualization of analytical heterogeneity on the profile of variables (features) in ComBat-Parametric -corrected data
#'
#'\emph{profplotpcom} allows you to adjust the data for batch effect using Parametric Empirical Bayes approach as described by \emph{Johnson et al.(2007)} and via \emph{sva} package as explained by \emph{Leek et al.(2012)}, and informs you about the presence of across batch signal drift or batch effect in the treated data, determined by the shifted \emph{probability density function} plots (\emph{pdf} plots) of variables (features) detected in an experiment.\cr
#'install.packages (c("ggplot2","ggfortify"))\cr
#'source("https://bioconductor.org/biocLite.R")\cr
#'biocLite(c("pcaMethods","impute","sva","limma","genefilter"))
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#' @return Original dataset in \emph{csv} format together with the series of profile plot for the variables( features) in the sample sets analyzed in the entire experiment provided by the \bold{Scatter} plot,\bold{Violin} plot and \bold{Density} plot compiled into \emph{pdf}.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed functions implemented in \code{dbnorm} package. Input must be normalized and transformed beforehand.
#'@keywords Parametric ComBat and profile plot
#'@references Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#' Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3),1))
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#' @export
profplotpcom<- function(m){
  origibal<-(m);
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE);#parametric
  y<- t(com_p)
  g<- data.frame(m[,1],y);
  colnames(g)[1] <- "Batch"
  pdf('ProfilePlot_ComBatPara.pdf')
  loop.vector<- 1:length(m[,-1]);
  for (i in loop.vector){
    x<- y[,i]
    xx<-g[,i+1]
    n<-median(y[,i])
    std<-sd(y[,i])
    par (mfrow=c(3,1))
    myplot<-plot(m[,1],x,col = "black",main=colnames(m)[i+1],xlab="Batch",ylab = "Normalized intensity")
    abline(h=n,col = "gray", lty = 1)
    abline(h=n+std,lty = 2,col = "gray")
    abline(h=n-std,lty = 2,col = "gray")
    lines(lowess(m[,1],x),col="red4")
    dplot<-ggplot(g, aes(x=xx, colour=as.factor(g[,1]))) +
      geom_density()+theme_bw()+ggtitle(colnames(m)[i+1])+
      labs(x=" Normalized intensity", caption = "(based on ComBat Parametric)")+
      theme_classic()
    p <- ggplot(g, aes(x=as.factor(g[,1]), y=xx)) +
      geom_violin(trim=FALSE, fill='gray', color="black")+geom_jitter(shape=19,position=position_dodge(1))+
      labs(x="Batch", y="Normalized intensity", title=colnames(g)[i+1])+geom_boxplot(width=0.1)

    write.csv(m,file = "original.csv")
    write.csv(g,file="Data_ComBat_Parametric.csv")
    print(p)
    print(myplot)
    print(dplot)

  }
  dev.off()
}
#'
#'Visualization of analytical heterogeneity on the profile of variables (features) in ComBat-Non Parametric- corrected data
#'
#'\emph{profplotnpcom} allows you to adjust the data for batch effect based on Non-Parametric Empirical Bayes}approach as described by \emph{Johnson et al.(2007)} and via \emph{sva} package as explained by \emph{Leek et al.(2012)}, and informs you about the presence of across batch signal drift or batch effect in the treated data, determined by the shifted \emph{probability density function} plots (\emph{pdf} plots) of variables (features) detected in an experiment.\cr
#'#'install.packages (c("ggplot2","ggfortify"))\cr
#'source("https://bioconductor.org/biocLite.R")\cr
#'biocLite(c("pcaMethods","impute","sva","limma","genefilter"))
#'
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#'@return Original dataset in \emph{csv} format together with the series of profile plot of the feature (variable) in all samples analyzed in the entire experiment provided by \bold{Scatter} plot,\bold{Violin} plot and \bold{Density} plot compiled into a \emph{pdf}.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed beforehand.
#'@keywords Non Parametric ComBat and profile plot
#'@references Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'@examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3),1))
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#'
#'@export
profplotnpcom<- function(m){
  origibal<-(m);
  com_n<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=F);# nonParametric
  y<- t(com_n)
  g<- data.frame(m[,1],y);
  colnames(g)[1] <- "Batch"
  pdf('ProfilePlot_NPComBat.pdf')
  loop.vector<- 1:length(m[,-1]);
  for (i in loop.vector){
    x<- y[,i]
    xx<-g[,i+1]
    n<-median(y[,i])
    std<-sd(y[,i])
    par (mfrow=c(3,1))
    myplot<-plot(m[,1],x,col = "black",main=colnames(m)[i+1],xlab="Batch",ylab = "Normalized intensity")
    abline(h=n,col = "gray", lty = 1)
    abline(h=n+std,lty = 2,col = "gray")
    abline(h=n-std,lty = 2,col = "gray")
    lines(lowess(m[,1],x),col="red4")
    dplot<-ggplot(g, aes(x=xx, colour=as.factor(g[,1]))) +
      geom_density()+theme_bw()+ggtitle(colnames(m)[i+1])+
      labs(x=" Normalized intensity", caption = "(based on ComBat NonParametric)")+
      theme_classic()
    p <- ggplot(g, aes(x=as.factor(g[,1]), y=xx)) +
      geom_violin(trim=FALSE, fill='gray', color="black")+geom_jitter(shape=19,position=position_dodge(1))+
      labs(x="Batch", y="Normalized intensity", title=colnames(g)[i+1])+geom_boxplot(width=0.1)

    write.csv(m,file = "original.csv")
    write.csv(g,file="Data_ComBat_NonParametric.csv")####
    print(p)
    print(myplot)
    print(dplot)

  }
  dev.off()
}
#'
#'
#'
#'Clustering and regression analysis of data normalization via ber- model and visualization
#'
#'This function allows you to adjust the data for across batch signal drift or batch effect  using two-stage procedure approach as described by \emph{M. Giordan (2013)} and includes advanced statistical tools to inspect the structure and quality of high throughput experiment both macroscopically and microscopically at the level of sample sets and metabolic feature, respectively. Notably, using this function users perform unsupervised clustering analysis on the raw and the treated dataset. In parallel, \emph{Adjusted- R squared} value for each variable (feature) estimated by regression model is calculated, which demonstrate the dependency of variable (feature) to the batch level in either of those datasets. In addition, for quick notification about the performance of the applied model two scores are reported, which are calculated based on the total degree of variability and the maximum variability. These scores notify respectively the overall performance of the model and the consistency of model performance for all detected variables (features).\cr
#'install.packages (c("ggplot2", "NormalizeMets","ggfortify", "factoextra","MASS","ber"))\cr
#'source("https://bioconductor.org/biocLite.R")\cr
#'biocLite(c("pcaMethods","impute","limma","genefilter"))
#'
#' @param f A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#'
#' @return An adjusted dataset in \emph{csv} format together with a series of graphical displays such as \bold{PCA} score plot, \bold{Scree} plot, and and plot of \emph{Adjusted-R squared} value for the variables (features) compiled into \emph{pdf}. In addition, the \emph{Adjusted- R squared} value for each variables for the raw and corrected datasets separately saved in \emph{csv}. Besides, a table of \emph{Sum} and \emph{Maximum} \emph{Adjusted-R squared} presented in \emph{csv}. \bold{RLA} plot visualized in the \emph{Viewer} panel in the \emph{rstudio} console.
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed beforehand.
#'
#' @keywords  Clustering and regression for normalized data via ber-model
#' @references
#' M.Giordan (2013) \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'f<-data.frame(batch,y)
#' @export
dbnormBer<- function(f){
  colnames(f)[1]<-"Batch";
  pdf("ber_dbnorm.pdf")
  par(mar=c(5.1,4.1,1,1))
  y<- ber(as.matrix(f[,-1]),as.factor(f[,1]));#two-stage regression
  p<-prcomp(f[,-1],scale=T)
  p.c<-prcomp(y,scale=T);
  pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="ber-corrected");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_Raw")
  sc.b<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_ber-Corrected")
  g<-data.frame(f[1],y);
  rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_raw")
  rlp.c<-RlaPlots( y, f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_Ber")
  corr.b<-sapply(2:ncol(g),function(i){
    fit.b <- lm(g[,i]~ as.factor(g[,1]))
    return( summary(fit.b)[["adj.r.squared"]])
  })
  corr<-sapply(2:ncol(f),function(i){
    fit <- lm(f[,i]~ as.factor(f[,1]))
    return( summary(fit)[["adj.r.squared"]])
  })
  p.ber<-plot(seq(along=corr.b), corr.b, xlab="variable",ylab="adj.r.squared", main="ber-corrected")
  names(corr.b)<- names(f[-1])
  p.raw <-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.squared", main="raw-DATA")
  names(corr)<- names(f[-1])
  write.csv(corr.b, file="ber_data_adjRsquared.csv")
  write.csv(cor, file="Rawdata_adjRsquared.csv")
  write.csv(g,file = "mydata_berCorrected.csv")
  a1<-abs (corr[1:length(corr)])
  a11<-sum(a1)
  a12<-max(a1)
  a2<-abs (corr.b[1:length(corr.b)])
  a21<-sum(a2)
  a22<-max(a2)
  datf<-data.frame(Dataset=c("Raw","ber"),SumadjRSq=c(a11,a21),
                   MaxdjRSq=c(a12,a22) );
  write.csv(datf,file = "SCore_adjRSq.csv")

  print(sc)
  print(sc.b)
  print(pca)
  print(pca.c)
  print(rlp)
  print(rlp.c)
  print(p.ber)
  print(p.raw)
  dev.off()
}
#'Clustering and regression analysis of data normalization via ComBat-Parametric model and visualization
#'
#'This function allows you to adjust the data for across batch signal drift or batch effect  using Parametric Empirical Bayes approach as described by \emph{Johnson et al.(2007)} and via \emph{sva} package as explained by \emph{Leek et al.(2012)}. \emph{dbnormPcom} includes advanced statistical tools to inspect the structure and quality of high throughput experiment both macroscopically and microscopically at the sample batch level and metabolic feature level, respectively. Notably, using this function users perform unsupervised clustering analysis of the raw data and the treated dataset. In parallel, \emph{Adjusted- R squared} value for each variable (feature) estimated by regression model is calculated, which demonstrate the dependency of variable (feature) to the batch level in either of those datasets. In addition, for quick notification about the performance of the applied model two scores are reported, which are calculated based on the total degree of variability and the maximum variability. These scores notify respectively the overall performance of the model and the consistency of model performance for all detected variables (features).\cr
#'install.packages (c("ggplot2", "NormalizeMets","ggfortify", "factoextra"))\cr
#'source("https://bioconductor.org/biocLite.R")\cr
#'biocLite(c("pcaMethods","impute","sva","limma","genefilter"))
#' @param f A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#'
#'@return An adjusted dataset in \emph{csv} format together with a series of graphical displays such as \bold{PCA} score plot, \bold{Scree} plot, and and plot of \emph{Adjusted-R squared} value for the variables (features) compiled into \emph{pdf}. In addition, the \emph{Adjusted- R squared} value for each variables for the raw and corrected datasets separately saved in \emph{csv}. Besides, a table of \emph{Sum} and \emph{Maximum} \emph{Adjusted-R squared} presented in \emph{csv}. \bold{RLA} plot visualized in the \emph{Viewer} panel in the \emph{rstudio} console.

#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed beforehand.
#'
#' @keywords  Clustering and regression for normalized data via ber-model
#'@references Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'f<-data.frame(batch,y)
#' @export
#'
dbnormPcom<- function(f){
  colnames(f)[1]<-"Batch";
  pdf("ComBatParametric_dbnorm.pdf")
  par(mar=c(5.1,4.1,1,1))
  com_p<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
  g<-data.frame(f[1],t(com_p));
  p<-prcomp(f[,-1],scale=T)
  p.c<-prcomp(g[,-1],scale=T);
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+labs(title ="PCA-raw")
  sc.c<-fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+labs(title ="PCA-ComBat-Parametric")
  pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="ComBatParametric_corrected");
  rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot-raw")
  rlp.c<-RlaPlots( g[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot-ComBatParametric")
  corr.c<-sapply(2:ncol(g),function(i){
    fit.c <- lm(g[,i]~ as.factor(g[,1]))
    return( summary(fit.c)[["adj.r.squared"]])
  })
  corr<-sapply(2:ncol(f),function(i){
    fit <- lm(f[,i]~ as.factor(f[,1]))
    return( summary(fit)[["adj.r.squared"]])
  })
  p.com<-plot(seq(along=corr.c), corr.c, xlab="variable",ylab="adj.r.squared", main="ComBatParametric-corrected")
  names(corr.c)<- names(f[-1])
  p.raw <-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.squared", main="raw-DATA")
  names(corr)<- names(f[-1])
  write.csv(corr.c, file="ComBatParametric_adjRsquared.csv")
  write.csv(cor, file="Rawdata_adjRsquared.csv")
  write.csv(g,file = "mydata_ComBatParametricCorrected.csv")

  print(sc)
  print(sc.c)
  print(pca)
  print(pca.c)
  print(rlp)
  print(rlp.c)
  print(p.com)
  print(p.raw)
  dev.off()

}
#'Clustering and regression analysis of data normalization via ComBat-NonParametric model and visualization
#'
#'This function allows you to adjust the data for across batch signal drift or batch effect  using Non-Parametric Empirical Bayes approach as described by \emph{Johnson et al.(2007)} and in \link{sva} package. \emph{dbnormNPcom} includes advanced statistical tools to inspect the structure and quality of high throughput experiment both macroscopically and microscopically at the sample batch level and metabolic feature level, respectively. Notably, using this function users perform unsupervised clustering analysis of the raw data and the treated dataset. In parallel, \emph{Adjusted-R squared} value for each variable (feature) estimated by regression model is calculated, which demonstrate the dependency of variable (feature) to the batch level in either of those datasets. In addition, for quick notification about the performance of the applied model two scores are reported, which are calculated based on the total degree of variability and the maximum variability. These scores notify respectively the overall performance of the model and the consistency of model performance for all detected variables (features).\cr
#'install.packages (c("ggplot2", "NormalizeMets","ggfortify", "factoextra"))\cr
#'source("https://bioconductor.org/biocLite.R")\cr
#'biocLite(c("pcaMethods","impute","sva","limma","genefilter"))
#'
#' @param f A data frame in which rows define the independent experiments (samples) and columns the features (variables).Batch order must be framed in the first column.
#'
#' @return An adjusted dataset in \emph{csv} format together with a series of graphical displays such as \bold{PCA} score plot, \bold{Scree} plot, and and plot of \emph{Adjusted-R squared} value for the variables (features) compiled into \emph{pdf}. In addition, the \emph{Adjusted- R squared} value for each variables for the raw and corrected datasets separately saved in \emph{csv}. Besides, a table of \emph{Sum} and \emph{Maximum} \emph{Adjusted-R squared} presented in \emph{csv}. \bold{RLA} plot visualized in the \emph{Viewer} panel in the \emph{rstudio} console.
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by  \code{emvf} or \code{emvd}, functions implemented in \code{dbnorm} package. Input must be normalized and transformed beforehand.
#'
#' @keywords  Clustering and regression for normalized data via ber-model
#'
#'@references Johnson et al.(2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#' @examples
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'f<-data.frame(batch,y)
#' @export
dbnormNPcom<- function(f){
  colnames(f)[1]<-"Batch";
  pdf("ComBatNParametric_dbnorm.pdf")
  par(mar=c(5.1,4.1,1,1))
  com_np<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=FALSE, prior.plots=F);
  g<-data.frame(f[1],t(com_np));
  p<-prcomp(f[,-1],scale=T)
  p.c<-prcomp(g[,-1],scale=T);
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+labs(title ="PCA-raw")
  sc.c<-fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+labs(title ="PCA-ComBat-NParametric")
  pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="ComBatNParametric-corrected");
  rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot-raw")
  rlp.c<-RlaPlots( g[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot-NComBatparametric")
  corr.c<-sapply(2:ncol(g),function(i){
    fit.c <- lm(g[,i]~ as.factor(g[,1]))
    return( summary(fit.c)[["adj.r.squared"]])
  })
  corr<-sapply(2:ncol(f),function(i){
    fit <- lm(f[,i]~ as.factor(f[,1]))
    return( summary(fit)[["adj.r.squared"]])
  })
  p.com<-plot(seq(along=corr.c), corr.c, xlab="variable",ylab="adj.r.squared", main="ComBatParametric-corrected")
  names(corr.c)<- names(f[-1])
  p.raw <-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.squared", main="raw-DATA")
  names(corr)<- names(f[-1])
  write.csv(corr.c, file="ComBatNParametric_adjRsquared.csv")
  write.csv(cor, file="Rawdata_adjRsquared.csv")
  write.csv(g,file = "mydata_ComBatNParametricCorrected.csv")
  print(sc)
  print(sc.c)
  print(pca)
  print(pca.c)
  print(rlp)
  print(rlp.c)
  print(p.com)
  print(p.raw)
  dev.off()

}
