#' Estimation of missing value feature-based
#'
#'It returns to a matrix of data in which missing values (Zero and/or NA values) are estimated. By this function, all Zero values are first replaced by NA values, which are then replaced by the lowest detected value on the column margin.
#'@param m An array or a matrix
#'@keywords Missing value estimation
#'@details empty entries are not allowed
#'@return A matrix with estimated missing value.
#'@examples
#' m<- data.frame(x1=c(50,NA,6,10,30),x2=c(2,8,NA,15,0))
#'
#'@export
emvf <-function(m){
  apply(m, 2, function (x) {
    x[x == 0] <- NA;
    x<-as.numeric(as.character(x))
    x[is.na(x)] = min(x[x >0], na.rm=TRUE)
    x
  }
  )
}
#'Estimation of missing value data-based
#'
#'It returns to a matrix of data in which missing values are estimated by the lowest detected value in the entire experiment. By this function, all NA values are replaced by Zero values, that of being ultimately replaced by the lowest value detected in the experiment. Ultimately, data matrix is transposed to restore original structure.
#'
#' @param m An array or a matrix
#' @keywords Missing value estimation
#' @details empty entries are not allowed
#' @return  A matrix with estimated missing value.
#'@examples
#' m<- data.frame(x1=c(50,NA,6,10,30),x2=c(2,8,NA,15,0))
#' @export
emvd<- function(m){
  t(apply (m, 1,function(x){
    x[is.na(x)] <- 0
    small <- min(length(x))
    x[x == 0] <- NA
    x[is.na(x)] <- small
    x
  }
  )
  )
}
#'
#'
#'
#'
#'
#'
#'Visualization of signal drift across batch normalization
#'
#'This function performs batch effect adjustment via three statistical models implemented in the \code{dbnorm}, namely two-stage procedure as described by \emph{Giordan (2013)} and/or empirical Bayes methods in two setting of parametric and non-parametric as described by \emph{Johnson et al.(2007)} and in \emph{sva} package by \emph{Leek et al.(2012)}. Meanwhile, the graphical inferences in the context of unsupervised learning algorithms create visual inspection to inform users about the spatial separation of the sample sets analyzed in the different analytical runs alongside the distribution of the features (variables) in the raw and treated datasets. This function is suggested for less than 2000 features (variables) to speed up the computational process. \cr
#'
#'@param f A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by \code{emvf} or \code{emvd}, functions implemented in the \code{dbnorm} package. Input data must be normalized prior.
#'@return  Three datasets, adjusted by either of applied statistical algorithms prepared in \bold{csv} and together with series of plot such as \emph{PCA} plot and \emph{Scree plot} compiled into a \bold{PDF} file are saved in the working directory. \emph{RLA} plots are represented in the \bold{Viewer} panel of \bold{rstudio}.
#'@keywords Visualization and across batch normalization
#'
#'@references M.Giordan (2013) \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}\cr
#'Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#'@examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'f<-data.frame(batch,y)
#'@export
Visdbnorm<- function(f){
com_p<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
com_n<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
colnames(f)[1]<-"Batch";
y<- ber(as.matrix(f[,-1]),as.factor(f[,1]));#two-stage regression
m_p<- data.frame(f[1],t(com_p));
m_n<- data.frame(f[1],t(com_n));
pdf("dbnorm_plots.pdf")
p<-prcomp(f[,-1],center=T,scale=T)
p.c<-prcomp(y,center=T,scale=T);
p.c_p<-prcomp(m_p[-1],center=T,scale=T);
p.c_n<-prcomp(m_n[-1],center=T,scale=T);
pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                  addEllipses=TRUE, ellipse.level=0.95)+
  labs(title ="PCA-raw");
pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
  labs(title ="PCA-ber-corrected");
pca.p<-fviz_pca_ind(p.c_p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
  labs(title ="PCA-combatParametric-corrected");
pca.n<-fviz_pca_ind(p.c_n,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
  labs(title ="PCA-combatNonparametric-corrected");

sp<- screeplot(p, type = "l", npcs = 10, main = " First 10 PCs_raw",ylim=c(0,100))
abline(h = 1, col="red", lty=5)
labs(title ="raw-data",x = "PC", y = "Variance")
legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
sp.cor<- screeplot(p.c, type = "l", npcs = 10, main = "First 10 PCs-ber")
abline(h = 1, col="red", lty=5)
labs(title ="ber-data",x = "PC", y = "Variance")
legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
sp.p<- screeplot(p.c_p, type = "l", npcs = 10, main = "First 10 10 PCs-ComBatParametric")
abline(h = 1, col="red", lty=5)
labs(title ="ComBat-Parametric",x = "PC", y = "Variance")
legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
sp.n<- screeplot(p.c_n, type = "l", npcs = 10, main = "First 10 PCs-ComBatNParametric")
abline(h = 1, col="red", lty=5)
labs(title ="ComBat-NonParametric",x = "PC", y = "Variance")
legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
g<-data.frame(f[1],y);
write.csv(g,file="mydata_ber_corrected.csv");
write.csv(m_p,file="mydata_ComBatParametric.csv")
write.csv(m_n,file="mydata_ComBatNonParametric.csv")
rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_raw")
rlp.c<-RlaPlots( y, f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_Ber")
rlp.p<-RlaPlots( m_p[-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ComBatParametric")
rlp.n<-RlaPlots( m_n[-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ComBatNonParametric")
par (mfrow=c(8,1))
print(sp)
print(sp.cor)
print(sp.p)
print(sp.n)
print(pca)
print(pca.c)
print(pca.p)
print(pca.n)
print(rlp)
print(rlp.c)
print(rlp.p)
print(rlp.n)
dev.off()
}
#'
#'
#'
#'
#'Adjusted coefficient of determination for a data normalized for across batch signal drift
#'
#'This function gives a quick notification about the performance of the statistical models implemented in the \code{dbnorm} package such as \emph{Giordan (2013)} and/or empirical Bayes methods in two setting of parametric and non-parametric as described by \emph{Johnson et al.(2007)} and in \emph{sva} package by \emph{Leek et al.(2012)}. It calculates and plots adjusted coefficient of determination or \emph{Adjusted R-Squared} for each variable estimated in a regression model for its dependency to the batch level in the raw data and treated data via either of those models. Immediately, a score calculated based on the maximum variability explained by the batch level presents the performance of applied models. This score notifies the consistency of a model performance for all detected features (variables), facilitating quick comparison of the models for selecting one of those models, which is more appropriate to the data structure. This function is suggested for less than 2000 features (variables) to keep maximum computational speed.\cr
#'
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by \code{emvf} or \code{emvd}, functions implemented in \code{dbnorm} package. Input data must be normalized prior.
#'@return  Several graphs compiled into a \bold{PDF} file which are a \emph{correlation} plot for each of applied models, a grouped \emph{barplot} presenting the maximum variability associated with batch levels in the raw and the corrected datasets.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected via either of applied models. Also, a two column matrix for Adjusted R-Square for raw and corrected datasets and a table summarizing the score values presented in \emph{barplot}.
#'@keywords Adjusted R-square
#'@references M.Giordan (2013) \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}\cr
#'Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#'
#'@examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#'@export
ACDdbnorm <- function(m){
colnames(m)[1]<-"Batch";
com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
com_n<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
y<- ber(as.matrix(m[,-1]),as.factor(m[,1]));#two-stage regression
g<-data.frame(m[,1],y);
pcom<-data.frame(m[1],t(com_p));
npcom<-data.frame(m[1],t(com_n));
corr <- sapply(2:ncol(m),function(i){
  fit <- lm(m[,i]~ as.factor(m[,1]))
  return( summary(fit)[["adj.r.square"]])
});
corr.b<-sapply(2:ncol(g),function(i){
  fit.b <- lm(g[,i]~ as.factor(g[,1]))
  return( summary(fit.b)[["adj.r.square"]])
})
corr.cp<-sapply(2:ncol(pcom),function(i){
  fit.cp <- lm(pcom[,i]~ as.factor(m[,1]))
  return( summary(fit.cp)[["adj.r.square"]])
});

corr.ncp<-sapply(2:ncol(npcom),function(i){
  fit.ncp <- lm(npcom[,i]~ as.factor(m[,1]))
  return( summary(fit.ncp)[["adj.r.square"]])
})
write.csv(y,file = "mydata_berData.csv")
write.csv(pcom,file = "mydata_pComBatData.csv")
write.csv(npcom,file = "mydata_npComBatData.csv")
names(corr)<- names(m[-1])
write.csv(corr, file="rawData_adjRsquare.csv")
names(corr.b)<- names(m[-1])
write.csv(corr.b, file="berData_adjRsquare.csv")
names(corr.cp)<- names(m[-1])
write.csv(corr.cp, file="pComBat_adjRsquare.csv")
names(corr.ncp)<- names(m[-1])
write.csv(corr.ncp, file="npComBatdata_adjRsquare.csv")
a1<- abs (corr [1:length(corr)])
a12<-max(a1)
a2<- abs(corr.b[1:length(corr.b)])
a22<-max(a2)
a3<- abs (corr.cp[1:length(corr.cp)])
a32<-max(a3)
a4<-abs (corr.ncp[1:length(corr.ncp)])
a42<-max(a4)
datf<-data.frame(Dataset=c("raw","npcom","pcom","ber"),
                 MaxdjRSq=c(a12,a42,a32,a22) );
write.csv(datf,file = "SCore_adjRSq.csv")

pdf("AdjRSQ_plot.pdf")
p.raw<-plot(seq(along=corr), corr.b, xlab="variable",ylab="adj.r.square", main="rawData")
p.b<-plot(seq(along=corr.b), corr.b, xlab="variable",ylab="adj.r.square", main="berData")
p.cp<-plot(seq(along=corr.cp), corr.cp, xlab="variable",ylab="adj.r.square", main="pComBatData")
p.ncp<-plot(seq(along=corr.ncp), corr.ncp, xlab="variable",ylab="adj.r.square", main="npComBatData")
pmaxim<-ggplot(data=datf, aes(x=reorder(Dataset, -MaxdjRSq), y=MaxdjRSq, fill=Dataset)) +
  geom_bar(stat="identity",width= 1)+
  theme_classic()
pmaxim<-pmaxim + labs(x = "Dataset (raW vs Model-corrected Data)")
pmaxim<-pmaxim + labs(y = "Maximum adj.R.Square")
pmaxim<- pmaxim + coord_flip()
print(p.raw)
print(p.b)
print(p.cp)
print(p.ncp)
print(pmaxim)
dev.off()
}
#'
#'
#'Visualization of analytical heterogeneity on the profile of features (variables) in raw data
#'
#'This function informs you about the presence of across batch signal drift or batch effect in the raw data determined by the shifted probability density function plots (\emph{pdf} plots) of features (variables) detected in an experiment.\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch level in the first column.
#' @return Original dataset in \bold{csv} format together with the series of profile plot for the features (variables) in the sample sets analyzed in the entire experiment provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into \bold{PDF} file.\cr
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#' @keywords raw data profile plot
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3),1))
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#' @export
profplotraw<- function (m)
{
  origibal <- (m)
  colnames(m)[1] <- "Batch"
  pdf("ProfilePlot_RawData.pdf")
  loop.vector <- 1:length(m[, -1])
  for (i in loop.vector) {
    x <- m[, i + 1]
    n <- median(m[, i + 1])
    std <- sd(m[, i + 1])
    par(mfrow = c(3, 1))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i +1],
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    dplot <- ggplot(m, aes(x = x, colour = as.factor(m[,1]))) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i +1]) +
      labs(x="Batch", caption = "(based on Raw_Data)") + theme_classic()
    p <- ggplot(m, aes(x = as.factor(m[, 1]), y = x)) +
      geom_violin(trim = FALSE,
                  fill = "gray", color = "black") +
      geom_jitter(shape = 19,position = position_dodge(1)) +
      labs(x="Batch",y="Normalized intensity", title = colnames(m)[i +1]) +
      geom_boxplot(width = 0.1)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}

#'Visualization of analytical heterogeneity on the profile of features (variables) in ber- corrected data
#'
#'\emph{profplotber} allows you to adjust the data for batch effect using two-stage procedure approach as describes by \emph{Giordan (2013)} and informs you about the presence of across batch signal drift or batch effect in the treated data determined by the shifted probability density function plots (\emph{pdf} plots) of features (variables) detected in an experiment.\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#' @return Original and adjusted datasets in \bold{csv} format together with the series of profile plot for the variables( features) in the sample sets analyzed in the entire experiment provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into \bold{PDF} file.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#' @keywords ber correction and profile plot
#' @references M.Giordan (2013) \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3),1))
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#' @export
profplotber<- function (m){
  origibal <- (m)
  y <- ber(as.matrix(m[, -1]), as.factor(m[, 1]))
  g <- data.frame(data.frame(m[, 1], y))
  colnames(g)[1] <- "Batch"
  pdf("ProfilePlot_berCorrected.pdf")
  loop.vector <- 1:length(m[, -1])
  for (i in loop.vector) {
    x <- y[, i]
    xx <- g[, i + 1]
    n <- median(y[, i])
    std <- sd(y[, i])
    par(mfrow = c(3, 1))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i + 1],
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    dplot <- ggplot(g, aes(x = xx, colour = as.factor(g[,1]))) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i + 1]) +
      labs(x= "Normalized intensity", caption = "(based on ber-Corrected)") +
      theme_classic()
    p <- ggplot(g, aes(x = as.factor(g[, 1]), y = xx)) +
      geom_violin(trim = FALSE, fill = "gray", color = "black") +
      geom_jitter(shape = 19, position = position_dodge(1)) +
      labs(x= "Batch", y= "Normalized intensity", title = colnames(g)[i + 1]) +
      geom_boxplot(width = 0.1)
    write.csv(m, file = "originalDataset.csv")
    write.csv(g, file = "ber_corrected_data.csv")
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#'Visualization of analytical heterogeneity on the profile of features (variables) in ComBat-Parametric -corrected data
#'
#'\emph{profplotpcom} allows you to adjust the data for batch effect using Parametric Empirical Bayes approach as described by \emph{Johnson et al.(2007)} and via \emph{sva} package as explained by \emph{Leek et al.(2012)}, and informs you about the presence of across batch signal drift or batch effect in the treated data, determined by the shifted probability density function plots (\emph{pdf} plots) of features (variables) detected in an experiment.\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#' @return Original and adjusted datasets in \bold{csv} format together with the series of profile plot for the features(variables) in the sample sets provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into a \bold{PDF} file.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed functions implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#'@keywords Parametric ComBat and profile plot
#'@references Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#' Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3),1))
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#' @export
profplotpcom<- function(m){
  origibal<-(m);
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE);#parametric
  y<- t(com_p)
  g<- data.frame(m[,1],y);
  colnames(g)[1] <- "Batch"
  pdf('ProfilePlot_ComBatPara.pdf')
  loop.vector<- 1:length(m[,-1]);
  for (i in loop.vector){
    x<- y[,i]
    xx<-g[,i+1]
    n<-median(y[,i])
    std<-sd(y[,i])
    par (mfrow=c(3,1))
    myplot<-plot(m[,1],x,col = "black",main=colnames(m)[i+1],xlab="Batch",ylab = "Normalized intensity")
    abline(h=n,col = "gray", lty = 1)
    abline(h=n+std,lty = 2,col = "gray")
    abline(h=n-std,lty = 2,col = "gray")
    lines(lowess(m[,1],x),col="red4")
    dplot<-ggplot(g, aes(x=xx, colour=as.factor(g[,1]))) +
      geom_density()+theme_bw()+ggtitle(colnames(m)[i+1])+
      labs(x=" Normalized intensity", caption = "(based on ComBat Parametric)")+
      theme_classic()
    p <- ggplot(g, aes(x=as.factor(g[,1]), y=xx)) +
      geom_violin(trim=FALSE, fill='gray', color="black")+geom_jitter(shape=19,position=position_dodge(1))+
      labs(x="Batch", y="Normalized intensity", title=colnames(g)[i+1])+geom_boxplot(width=0.1)

    write.csv(m,file = "originalDataset.csv")
    write.csv(g,file="Data_ComBat_Parametric.csv")
    print(p)
    print(myplot)
    print(dplot)

  }
  dev.off()
}
#'
#'Visualization of analytical heterogeneity on the profile of features (variables) in Non-Parametric ComBat corrected data
#'
#'\emph{profplotnpcom} allows you to adjust the data for batch effect based on Non-Parametric Empirical Bayes}approach as described by \emph{Johnson et al.(2007)} and via \emph{sva} package as explained by \emph{Leek et al.(2012)}, and informs you about the presence of across batch signal drift or batch effect in the treated data, determined by the shifted probability density function plots (\emph{pdf} plots) of features (variables) detected in an experiment.\cr
#'
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'@return Original and adjusted datasets in \bold{csv} format together with the series of profile plot of the features (variables) in the sample sets provided by \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into a \bold{PDF} file.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#'@keywords Non Parametric ComBat and profile plot
#'@references Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'@examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3),1))
#'y<- matrix(rnorm(2100),nrow=21)
#'m<-data.frame(batch,y)
#'
#'@export
profplotnpcom<- function(m){
  origibal<-(m);
  com_n<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=F);# nonParametric
  y<- t(com_n)
  g<- data.frame(m[,1],y);
  colnames(g)[1] <- "Batch"
  pdf('ProfilePlot_NPComBat.pdf')
  loop.vector<- 1:length(m[,-1]);
  for (i in loop.vector){
    x<- y[,i]
    xx<-g[,i+1]
    n<-median(y[,i])
    std<-sd(y[,i])
    par (mfrow=c(3,1))
    myplot<-plot(m[,1],x,col = "black",main=colnames(m)[i+1],xlab="Batch",ylab = "Normalized intensity")
    abline(h=n,col = "gray", lty = 1)
    abline(h=n+std,lty = 2,col = "gray")
    abline(h=n-std,lty = 2,col = "gray")
    lines(lowess(m[,1],x),col="red4")
    dplot<-ggplot(g, aes(x=xx, colour=as.factor(g[,1]))) +
      geom_density()+theme_bw()+ggtitle(colnames(m)[i+1])+
      labs(x=" Normalized intensity", caption = "(based on ComBat NonParametric)")+
      theme_classic()
    p <- ggplot(g, aes(x=as.factor(g[,1]), y=xx)) +
      geom_violin(trim=FALSE, fill='gray', color="black")+geom_jitter(shape=19,position=position_dodge(1))+
      labs(x="Batch", y="Normalized intensity", title=colnames(g)[i+1])+geom_boxplot(width=0.1)

    write.csv(m,file = "originalDataset.csv")
    write.csv(g,file="Data_ComBat_NonParametric.csv")####
    print(p)
    print(myplot)
    print(dplot)

  }
  dev.off()
}
#'
#'
#'
#'drift across batch normalization via ber- model and visualization base on unsupervised learning algorithm  and regression analysis
#'
#'This function allows you to adjust the data for across batch signal drift or batch effect  using two-stage procedure approach as described by \emph{M.Giordan (2013)}.\emph{dbnormBer} includes advanced statistical tools to inspect the structure and quality of high throughput experiment both in macroscopic and microscopic scales at the level of sample sets and metabolic feature, respectively. Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R squared} is considered to define the level of dependency of feature ( variable) to the batch level in the raw and corrected datasets. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notify the consistency of model performance for all detected features (variables).\cr
#'
#' @param f A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'
#' @return  Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a \emph{correlation} plot estimated for raw and corrected data. Also, the \emph{RLA} plot for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#'
#' @keywords  Unsupervised and regression analysis for normalized data via ber-model
#' @references
#' M.Giordan (2013) \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'f<-data.frame(batch,y)
#' @export
dbnormBer<- function(f){
  colnames(f)[1]<-"Batch";
  pdf("ber_dbnorm.pdf")
  par(mar=c(5.1,4.1,1,1))
  y<- ber(as.matrix(f[,-1]),as.factor(f[,1]));#two-stage regression
  p<-prcomp(f[,-1],scale=T)
  p.c<-prcomp(y,scale=T);
  pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="ber data");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_rawData")
  sc.b<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_berData")
  g<-data.frame(f[1],y);
  rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_raw")
  rlp.c<-RlaPlots( y, f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ber")
  corr.b<-sapply(2:ncol(g),function(i){
    fit.b <- lm(g[,i]~ as.factor(g[,1]))
    return( summary(fit.b)[["adj.r.square"]])
  })
  corr<-sapply(2:ncol(f),function(i){
    fit <- lm(f[,i]~ as.factor(f[,1]))
    return( summary(fit)[["adj.r.square"]])
  })
  p.ber<-plot(seq(along=corr.b), corr.b, xlab="variable",ylab="adj.r.square", main="berData")
  names(corr.b)<- names(f[-1])
  p.raw <-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.square", main="rawDATA")
  names(corr)<- names(f[-1])
  write.csv(corr.b, file="berData_adjRsquare.csv")
  write.csv(cor, file="rawData_adjRsquare.csv")
  write.csv(g,file = "mydata_berCorrecte.csv")
  a1<-abs (corr[1:length(corr)])
  a12<-max(a1)
  a2<-abs (corr.b[1:length(corr.b)])
  a22<-max(a2)
  datf<-data.frame(Dataset=c("raw","ber"),
                   MaxdjRSq=c(a12,a22) );
  write.csv(datf,file = "SCore_adjRSq.csv")

  print(sc)
  print(sc.b)
  print(pca)
  print(pca.c)
  print(rlp)
  print(rlp.c)
  print(p.ber)
  print(p.raw)
  dev.off()
}
#'drift across batch normalization via Parametric- ComBat model and visualization base on unsupervised learning algorithm and regression analysis
#'
#'This function allows you to adjust the data for across batch signal drift or batch effect  parametric Empirical Bayes approach as described by \emph{Johnson et al.(2007)} and in \emph{sva} package as explained by \emph{Leek et al.(2012)}. emph{dbnormPcom}  includes advanced statistical tools to inspect the structure and quality of high throughput experiment both in macroscopic and microscopic scales at the level of sample sets and metabolic feature, respectively. Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R squared} is considered to define the level of dependency of feature (variable) to the batch level in the raw and corrected datasets. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notify the consistency of model performance for all detected features (variables).\cr
#' @param f A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'
#'@return Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a  \emph{correlation} plot for raw and corrected data. Also, the \emph{RLA} plots for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.


#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#'
#' @keywords  unsupervised analysis and regression for normalized data via ComBat-Parametric
#'@references Johnson et al. (2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#' @examples
#'
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'f<-data.frame(batch,y)
#' @export
#'
dbnormPcom<- function(f){
  colnames(f)[1]<-"Batch";
  pdf("pComBat_dbnorm.pdf")
  par(mar=c(5.1,4.1,1,1))
  com_p<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
  g<-data.frame(f[1],t(com_p));
  p<-prcomp(f[,-1],scale=T)
  p.c<-prcomp(g[,-1],scale=T);
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+labs(title ="PCA-rawData")
  sc.c<-fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+labs(title ="PCA-pComBatData")
  pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="parametric ComBat data");
  rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot-raw")
  rlp.c<-RlaPlots( g[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot-pComBat")
  corr.c<-sapply(2:ncol(g),function(i){
    fit.c <- lm(g[,i]~ as.factor(g[,1]))
    return( summary(fit.c)[["adj.r.square"]])
  })
  corr<-sapply(2:ncol(f),function(i){
    fit <- lm(f[,i]~ as.factor(f[,1]))
    return( summary(fit)[["adj.r.square"]])
  })
  p.com<-plot(seq(along=corr.c), corr.c, xlab="variable",ylab="adj.r.square", main="parametric ComBat Data")
  names(corr.c)<- names(f[-1])
  p.raw <-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.square", main="rawDATA")
  names(corr)<- names(f[-1])
  write.csv(corr.c, file="pComBatData_adjRsquare.csv")
  write.csv(cor, file="rawdata_adjRsquare.csv")
  write.csv(g,file = "mydata_parametricComBat.csv")

  print(sc)
  print(sc.c)
  print(pca)
  print(pca.c)
  print(rlp)
  print(rlp.c)
  print(p.com)
  print(p.raw)
  dev.off()

}
#'drift across batch normalization via nonParametric- ComBat model and visualization base on unsupervised learning algorithm and regression analysis
#'
#'This function allows you to adjust the data for across batch signal drift or batch effect  non-parametric Empirical Bayes approach as described by \emph{Johnson et al.(2007)} and in \emph{sva} package as explained by \emph{Leek et al.(2012)}. emph{dbnormNPcom}  includes advanced statistical tools to inspect the structure and quality of high throughput experiment both in macroscopic and microscopic scales at the level of sample sets and metabolic feature, respectively. Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R squared} is considered to define the level of dependency of feature (variable) to the batch level in the raw and corrected datasets. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notify the consistency of model performance for all detected features (variables).\cr
#'
#' @param f A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'
#' @return Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a  \emph{correlation} plot for raw and corrected dataset. Also, the \emph{RLA} plot for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.

#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by  \code{emvf} or \code{emvd}, functions implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#'
#' @keywords  unsupervised analysis and regression for normalized data via ComBat NON-Parametric
#'
#'@references Johnson et al.(2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#' @examples
#'batch<- rep(gl(3,7,labels = c(1:3)),1)
#'y<- matrix(rnorm(2100),nrow=21)
#'f<-data.frame(batch,y)
#' @export
dbnormNPcom<- function(f){
  colnames(f)[1]<-"Batch";
  pdf("NPcom_dbnorm.pdf")
  par(mar=c(5.1,4.1,1,1))
  com_np<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=FALSE, prior.plots=F);
  g<-data.frame(f[1],t(com_np));
  p<-prcomp(f[,-1],scale=T)
  p.c<-prcomp(g[,-1],scale=T);
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+labs(title ="PCA-raw")
  sc.c<-fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+labs(title ="PCA-npComBat")
  pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="npComBat data");
  rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot-raw")
  rlp.c<-RlaPlots( g[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot-npComBat")
  corr.c<-sapply(2:ncol(g),function(i){
    fit.c <- lm(g[,i]~ as.factor(g[,1]))
    return( summary(fit.c)[["adj.r.square"]])
  })
  corr<-sapply(2:ncol(f),function(i){
    fit <- lm(f[,i]~ as.factor(f[,1]))
    return( summary(fit)[["adj.r.square"]])
  })
  p.com<-plot(seq(along=corr.c), corr.c, xlab="variable",ylab="adj.r.square", main="non-parametric ComBat Data ")
  names(corr.c)<- names(f[-1])
  p.raw <-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.square", main="raw DATA")
  names(corr)<- names(f[-1])
  write.csv(corr.c, file="npComBat_adjRsquare.csv")
  write.csv(cor, file="rawdata_adjRsquare.csv")
  write.csv(g,file = "mydata_nparametricComBat.csv")
  print(sc)
  print(sc.c)
  print(pca)
  print(pca.c)
  print(rlp)
  print(rlp.c)
  print(p.com)
  print(p.raw)
  dev.off()

}
