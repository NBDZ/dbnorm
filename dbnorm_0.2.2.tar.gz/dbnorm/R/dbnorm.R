#' Visualization and normalization of signal drift across batches\cr
#'
#'  This function performs batch effect adjustment via three statistical models, namely two-stage procedure as described by M. Giordan (2013) < DOI:10.1007/s12561-013-9081-1> (see also "ber" and ber_bg ) and/or empirical Bayes methods in two setting of parametric and non-parametric as described by  Johnson et al., (2007) < DOI: 10.1093/biostatistics/kxj037 > ( see "comBat" in "sva", a package in bioconductor) . Meanwhile, the graphical inferences in the context of unsupervised learning algorithms create visual inspection to inform users about the spatial separation of the sample sets analyzed in the different analytical runs alongside the distribution of the features (variables) in the sample sets and across multiple batches. For bagging model, partial bagging model with n=150 bootstrap samples is considered.  \cr
#'@param f A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by \code{emvf} and /or \code{emvd}, functions implemented in the \code{dbnorm} package. Input data must be normalized prior.
#'@return  Three datasets, adjusted by either of applied statistical algorithms prepared in \bold{csv} and together with series of plot such as \emph{PCA} plot and \emph{Scree plot} compiled into a \bold{PDF} file are saved in the working directory. \emph{RLA} plots are represented in the \bold{Viewer} panel of \bold{rstudio}.
#'@keywords Visualization and across batch normalization
#'
#'@references M.Giordan (2013) < DOI:10.1007/s12561-013-9081-1 > \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}\cr
#'Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037>  \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#'@examples
#'\dontrun{
#'Visdbnorm
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'f<-data.frame(batch,y)
#'Visodbnorm(f)}
#'
#'@export
Visodbnorm<- function(f){
  repos = getOption("repos")
  repos[c("ber","NormalizeMets")] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  com_p<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
  com_n<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
  colnames(f)[1]<-"Batch";
  y<- ber(as.matrix(f[,-1]),as.factor(f[,1]));#two-stage regression
  yb<- ber_bg(as.matrix(f[,-1]),as.factor(f[,1]), partial=TRUE,nSim=150);#two-stage regression
  m_p<- data.frame(f[1],t(com_p));
  m_n<- data.frame(f[1],t(com_n));
  pdf("Visodbnorm_plot.pdf")
  p<-prcomp(f[,-1],center=T,scale=T)
  p.c<-prcomp(y,center=T,scale=T);
  p.bag<-prcomp(yb,center=T,scale=T);
  p.c_p<-prcomp(m_p[-1],center=T,scale=T);
  p.c_n<-prcomp(m_n[-1],center=T,scale=T);
  pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Raw Data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="CorrectedData \n ber-model");
  pca.bag<-fviz_pca_ind(p.bag,label="none",habillage=f$Batch,
                        addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="CorrectedData \n ber-bagging-model");
  pca.p<-fviz_pca_ind(p.c_p,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="CorrectedData \n parametric combat-model");
  pca.n<-fviz_pca_ind(p.c_n,label="none", habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="CorrectedData \n non-parametric ComBat-model");
  sp<- fviz_eig(p, main = "Raw Data")
  sp.ber<- fviz_eig(p.c, main = "Corrected Data: ber-model")
  sp.bag<- fviz_eig(p.bag, main = "Corrected Data: ber-bagging-model")
  sp.p<- fviz_eig(p.c_p, main = "Corrected Data: parametric ComBat-model" )
  sp.n<- fviz_eig(p.c_n, main = "Corrected Data: non-parametric ComBat-model")
  g<-data.frame(f[1],y)
  newfilename <- "myresult_ber.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(g, newfilepath)
  gb<-data.frame(f[1],yb)
  newfilename <- "myresult_ber_bagging.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(gb, newfilepath)
  newfilename <- "myresult_parametricCombat.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(m_p, newfilepath)
  newfilename <- "myresult_nonparametricCombat.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(m_n, newfilepath)
  rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_Raw Data")
  rlp.c<-RlaPlots( y, f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot Corrected Data\n ber-model")
  rlp.bag<-RlaPlots( yb, f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot Corrected Data\n ber-bagging-model")
  rlp.p<-RlaPlots( m_p[-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot Corrected Data\n parametric ComBat")
  rlp.n<-RlaPlots( m_n[-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot Corrected Data\n non-parametric ComBat")
  opar <- par(mfrow=c(8,1))
  on.exit(par(opar))
  print(sp)
  print(sp.ber)
  print(sp.bag)
  print(sp.p)
  print(sp.n)
  print(pca)
  print(pca.c)
  print(pca.bag)
  print(pca.p)
  print(pca.n)
  print(rlp)
  print(rlp.c)
  print(rlp.bag)
  print(rlp.p)
  print(rlp.n)
  dev.off()
}
#'Estimation of missing value feature-based
#'
#'This is a function in the \code{dbnorm}, a package in R. This function returns to a matrix of data in which missing values (Zero and/or NA values) are estimated. By this function, all Zero values are first replaced by NA values, which are then replaced by the lowest detected value on the column margin.\cr
#'@param m An array or a matrix
#'@keywords Missing value estimation
#'@details empty entries are not allowed
#'@return A matrix with estimated missing value.
#'@examples
#'m<- data.frame(x1=c(50,NA,6,10,30),x2=c(2,8,NA,15,0))
#'emvf(m)
#'@export
emvf <-function(m){
  apply(m, 2, function (x) {
    x[x == 0] <- NA;
    x<-as.numeric(as.character(x))
    x[is.na(x)] = min(x[x >0], na.rm=TRUE)
    x
  }
  )
}
#'Estimation of missing value data-based
#'
#'This is a function in the \code{dbnorm}, a package in R. It returns to a matrix of data in which missing values are estimated by the lowest detected value in the entire experiment. By this function, all NA values are replaced by Zero values, that of being ultimately replaced by the lowest value detected in the experiment. Ultimately, data matrix is transposed to restore original structure.\cr
#'
#' @param m An array or a matrix
#' @keywords Missing value estimation
#' @details empty entries are not allowed
#' @return  A matrix with estimated missing value.
#'@examples
#' m<- data.frame(x1=c(50,NA,6,10,30),x2=c(2,8,NA,15,0))
#' emvd(m)
#'
#' @export
emvd<- function(m){
  apply (m, 2,function(x){
    is.na(m) <- !m
    min.val = min(m, na.rm = T)
    x[is.na(x)]<-min.val
    x[x == 0] <- min.val;

    x
  }
  )
}
#'
#'Adjusted Coefficient Of Determination for a data normalized for signal drift across batches\cr
#'
#'It is a function in \code{dbnorm}, a package in R. This function gives a quick notification about the performance of the compiled statistical models namely two-stage regression procedure (see  functions such as "ber" and ber-bg using partial bagging model with n=150 bootstrap samples) and/or empirical Bayes methods in two setting of parametric and non-parametric (see "ComBat" in "sva", a package in bioconductor), on accommodation of batch effect. Using this function users will estimate values of adjusted coefficient of determination ( Adjusted R- Squared ) which address the dependency of each feature (variable) to the batch order in each dataset. Immediately, a score calculated based on the maximum variability estimated by the regression analysis is reported and presented in graph. This score notifies the consistency of a model performance for the detected features (variables), facilitating quick comparison of the models for selecting one of those models, which is more appropriate to the data structure.\cr
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by \code{emvf} or \code{emvd}, functions implemented in \code{dbnorm} package. Input data must be normalized prior.
#'@return  Several graphs compiled into a \bold{PDF} file which are a \emph{correlation} plot for each of applied models, a grouped \emph{barplot} presenting the maximum variability associated with batch levels in the raw and the corrected datasets.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected via either of applied models. Also, a two column matrix for Adjusted R-Square for raw and corrected datasets and a table summarizing the score values presented in \emph{barplot}.
#'@keywords Adjusted R-squared
#'@references Giordan (2013) < DOI:10.1007/s12561-013-9081-1 > \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}\cr
#'Johnson et al., (2007) < DOI: 10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034 >  \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#'@examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'dbnormSCORE(m)}
#'
#'@export
dbnormSCORE<- function(m){
  repos = getOption("repos")
  repos[c("ber","NormalizeMets")] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos);
  colnames(m)[1]<-"Batch";
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
  com_n<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
  y<- ber(as.matrix(m[,-1]),as.factor(m[,1]));#two-stage regression
  y.bag<- ber_bg(as.matrix(m[,-1]),as.factor(m[,1]),partial=TRUE,nSim=150);#two-stage regression
  g<-data.frame(m[,1],y);
  g.bag<-data.frame(m[,1],y.bag);
  pcom<-data.frame(m[1],t(com_p));
  npcom<-data.frame(m[1],t(com_n));
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]),drop.unused.levels = TRUE)
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.b<-sapply(2:ncol(g),function(i){
    fit.b <- lm(g[,i]~ as.factor(g[,1]),drop.unused.levels = TRUE)
    return( summary(fit.b)[["adj.r.squared"]])
  })
  corr.bag<-sapply(2:ncol(g.bag),function(i){
    fit.b.bag <- lm(g.bag[,i]~ as.factor(g.bag[,1]),drop.unused.levels = TRUE)
    return( summary(fit.b.bag)[["adj.r.squared"]])
  })
  corr.cp<-sapply(2:ncol(pcom),function(i){
    fit.cp <- lm(pcom[,i]~ as.factor(m[,1]),drop.unused.levels = TRUE)
    return( summary(fit.cp)[["adj.r.squared"]])
  });

  corr.ncp<-sapply(2:ncol(npcom),function(i){
    fit.ncp <- lm(npcom[,i]~ as.factor(m[,1]),drop.unused.levels = TRUE)
    return( summary(fit.ncp)[["adj.r.squared"]])
  })
  wd <- tempdir()
  pdf("dbnormSCORE.pdf")
  p1<-plot(seq(along=corr), corr, xlab="Features",ylab="adj.R2", main="RawData")
  p2<-plot(seq(along=corr.b), corr.b, xlab="Features",ylab="adj.R2", main="CorrectedData\n ber-model")
  p3<-plot(seq(along=corr.bag), corr.bag, xlab="Features",ylab="adj.R2", main="CorrectedData\n ber-bagging-model")
  p4<-plot(seq(along=corr.cp), corr.cp, xlab="Features",ylab="adj.R2", main="CorrectedData\n parametric ComBat-model")
  p5<-plot(seq(along=corr.ncp), corr.ncp, xlab="Features",ylab="adj.R2", main="CorrectedData\n non-parametric ComBat-model")
  names(corr)<- names(m[-1])
  newfilename <- "RawData_adjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.b)<- names(m[-1])
  newfilename <- "berData_adjR2.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.b, newfilepath)
  names(corr.cp)<- names(m[-1])
  newfilename <- "ParaComBatData_adjR2.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.cp, newfilepath)
  names(corr.ncp)<- names(m[-1])
  newfilename <- "NonParaComBatData_adjR2.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.ncp, newfilepath)
  names(corr.bag)<- names(m[-1])
  newfilename <- "ber_baggingData_adjR2.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.bag, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.b[1:length(corr.b)])
  as2<- sum(a2)
  am2<-max(a2)
  a2.bag<- abs(corr.bag[1:length(corr.bag)])
  am2.bag<-max(a2.bag)
  a3<- abs (corr.cp[1:length(corr.cp)])
  as3<-sum(a3)
  am3<-max(a3)
  a4<-abs (corr.ncp[1:length(corr.ncp)])
  as4<-sum(a4)
  am4<-max(a4)
  datm<-data.frame(Dataset=c("Raw","nonpara-ComBat","para-ComBat","ber","ber-bagging"),adjRSq=c(am1,am4,am3,am2,am2.bag));
  newfilename <- "SCore_Max_adjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (Raw and Corrected)")
  pm<-pm + labs(y = "Maximum adj.R2")
  pm<- pm + coord_flip()
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(p5)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}
#'
#'
#'Profile Plot of Features (variables) in original data (Raw data)
#'
#' It is a function in the \code{dbnorm} This function informs you about the presence of across batch signal drift or batch effect in the raw data determined by the shifted probability density function plots (\emph{pdf} plots) of features (variables) detected in an experiment.\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch level in the first column.
#' @return Original dataset in \bold{csv} format together with the series of profile plot for the features (variables) in the sample sets analyzed in the entire experiment provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into \bold{PDF} file.\cr
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions such as \code{emvf} or \code{emvd} Compiled in the \code{'dbnorm'} package. Input must be normalized and transformed prior.
#' @keywords raw data profile plot
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#'
#' @examples
#' \dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5),1))
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'ProfPlotraw(m)
#'}
#'@export
ProfPlotraw <- function (m){
  origibal <- (m)
  colnames(m)[1] <- "Batch"
  pdf("ProfilePlot_RawData.pdf")
  loop.vector <- 1:length(m[, -1])
  for (i in loop.vector) {
    x <- m[, i + 1]
    n <- median(m[, i + 1])
    std <- sd(m[, i + 1])
    par(mfrow = c(3, 1))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i +1],drop.unused.levels = TRUE,
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    plt <- ggplot(m, aes(x = x, colour = as.factor(m[,1])),drop.unused.levels = TRUE) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i +1]) +
      labs(x="Batch", caption = "(based on Raw Data)") + theme_classic()
    dplot<-plt+ scale_colour_discrete(name  ="Batch")
    p<- ggplot(m, aes(x = as.factor(m[, 1]), y = x),drop.unused.levels = TRUE) +
      geom_violin(trim = FALSE,
                  fill = "gray", color = "black") +
      geom_jitter(shape = 19,position = position_dodge(1)) +
      labs(x="Batch",y="Normalized intensity", title = colnames(m)[i +1]) +
      geom_boxplot(width = 0.1)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#'
#' Profile Plot of Features (variables) in ber- corrected data
#'
#'It is a function in the \code{dbnorm}, a package in R. This function allows users to adjust the data for batch effect via location-scale (L/S) model (see also "ber" function and its package in R ). This function visualize the result for global profile of each feature across batches via (\emph{Scatter} plot), (\emph{Violin} plot) and (\emph{Density (or pdf)} plot).\cr
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#' @return Original and adjusted sets of data in \bold{csv} format together with the series of profile plot for the variables( features) in the sample sets analyzed in the entire experiment provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into \bold{PDF} file.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and/ or \code{emvd} implemented in the \code{dbnorm}. Input must be normalized and transformed prior.
#' @keywords ber correction and profile plot
#' @references M.Giordan (2013) < DOI:10.1007/s12561-013-9081-1 > \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#' @examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5),1))
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'profplotBer(m)
#'}
#' @export
ProfPlotBer<- function (m){
  repos = getOption("repos")
  repos["ber"] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  origibal <- (m)
  y <- ber(as.matrix(m[, -1]), as.factor(m[, 1]))
  g <- data.frame(m[, 1], y)
  colnames(g)[1] <- "Batch"
  pdf("ProfilePlot_BerData.pdf")
  loop.vector <- 1:length(m[,-1])
  for (i in loop.vector) {
    x <- y[, i]
    xx <- g[, i + 1]
    n <- median(y[, i])
    std <- sd(y[, i])
    opar <- par(mfrow=c(3,1))
    on.exit(par(opar))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i + 1],drop.unused.levels = TRUE,
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    plt <- ggplot(g, aes(x = xx, colour = as.factor(g[,1])),drop.unused.levels = TRUE) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i + 1])
    dplot<-plt+ scale_colour_discrete(name  ="Batch")
    labs(x= "Normalized intensity", caption = "(based on Corrected Data/n ber-model)") +
      theme_classic()
    p<- ggplot(g, aes(x = as.factor(g[, 1]), y = xx),drop.unused.levels = TRUE) +
      geom_violin(trim = FALSE, fill = "gray", color = "black") +
      geom_jitter(shape = 19, position = position_dodge(1)) +
      labs(x= "Batch", y= "Normalized intensity", title = colnames(g)[i + 1]) +
      geom_boxplot(width = 0.1)
    newfilename <- "originalData.csv"
    path_user <- dirname(file.path(tempdir(), newfilename))
    newfilepath <- file.path(path_user, newfilename)
    write.csv(m, newfilepath)
    newfilename <- "CorrectedData_ber.csv"
    newfilepath <- file.path(path_user, newfilename)
    write.csv(g, newfilepath)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#' Profile Plot of Features (variables) in corrected data using ber-bagging model
#'
#'It is a function in the \code{dbnorm}, a package in R. This function allows users to remove variance associated with batch using “partial bagging” model with n=150 bootstrap samples ( see also "ber_bg" function and its package in R ). This function visualize the result for global profile of each feature across batches via (\emph{Scatter} plot), (\emph{Violin} plot) and (\emph{Density (or pdf)} plot).\cr#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#' @return Original and adjusted datasets in \bold{csv} format together with the series of profile plot for the variables( features) in the sample sets analyzed in the entire experiment provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into \bold{PDF} file.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and/ or \code{emvd} implemented in the \code{dbnorm}. Input must be normalized and transformed prior.
#' @keywords ber correction and profile plot
#' @references M.Giordan (2013) < DOI:10.1007/s12561-013-9081-1 > \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#' @examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5),1))
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'ProfPlotBagging(m)
#'}
#' @export
ProfPlotBagging<- function (m){
  repos = getOption("repos")
  repos["ber"] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  origibal <- (m)
  y <- ber_bg(as.matrix(m[, -1]), as.factor(m[, 1]))
  g <- data.frame(m[, 1], y)
  colnames(g)[1] <- "Batch"
  pdf("ProfilePlot_berBaggingData.pdf")
  loop.vector <- 1:length(m[,-1])
  for (i in loop.vector) {
    x <- y[, i]
    xx <- g[, i + 1]
    n <- median(y[, i])
    std <- sd(y[, i])
    opar <- par(mfrow=c(3,1))
    on.exit(par(opar))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i + 1],drop.unused.levels = TRUE,
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    plt <- ggplot(g, aes(x = xx, colour = as.factor(g[,1])),drop.unused.levels = TRUE) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i + 1])
    dplot<-plt+ scale_colour_discrete(name  ="Batch")
    labs(x= "Normalized intensity", caption = "(based on Corrected Data/n ber-Baging-model)") +
      theme_classic()
    p<- ggplot(g, aes(x = as.factor(g[, 1]), y = xx),drop.unused.levels = TRUE) +
      geom_violin(trim = FALSE, fill = "gray", color = "black") +
      geom_jitter(shape = 19, position = position_dodge(1)) +
      labs(x= "Batch", y= "Normalized intensity", title = colnames(g)[i + 1]) +
      geom_boxplot(width = 0.1)
    newfilename <- "originalData.csv"
    path_user <- dirname(file.path(tempdir(), newfilename))
    newfilepath <- file.path(path_user, newfilename)
    write.csv(m, newfilepath)
    newfilename <- "CorrectedData_berBagging.csv"
    newfilepath <- file.path(path_user, newfilename)
    write.csv(g, newfilepath)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#' Profile Plot of Features (variables) in corrected data via  Parametric ComBat
#'
#'It is a function in the \code{dbnorm}, a package in R. This function allows users to adjust the data for batch effect using parametric \emph{Empirical Bayes} approach (see "ComBat" in "sva", a package in bioconductor ). \emph{profplotpcom} visualize the result for global profile of each feature across batches via (\emph{Scatter} plot), (\emph{Violin} plot) and (\emph{Density (or pdf)} plot).\cr
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#' @return Original and adjusted sets of data in \bold{csv} format together with the series of profile plot for the features(variables) in the sample sets provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into a \bold{PDF} file.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and/ or \code{emvd} implemented in the \code{'dbnorm'}. Input must be normalized and transformed prior.
#'@keywords Parametric ComBat and profile plot
#'@references Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034> \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#'
#' @examples
#' \dontrun{
#'batch<- rep(gl(2,3,labels=(1:2)),2)
#'y<- matrix(rnorm(6000), nrow=12)
#'m<- data.frame (batch,y)
#'ProfPlotComPara(m)
#'}
#' @export
ProfPlotComPara<- function (m){
  origibal <- (m)
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE);#parametric
  y<- t(com_p)
  g <- data.frame(m[, 1], y)
  colnames(g)[1] <- "Batch"
  pdf("ProfilePlot_paraComBatData.pdf")
  loop.vector <- 1:length(m[,-1])
  for (i in loop.vector) {
    x <- y[, i]
    xx <- g[, i + 1]
    n <- median(y[, i])
    std <- sd(y[, i])
    opar <- par(mfrow=c(3,1))
    on.exit(par(opar))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i + 1],drop.unused.levels = TRUE,
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    plt <- ggplot(g, aes(x = xx, colour = as.factor(g[,1])),drop.unused.levels = TRUE) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i + 1])
    dplot<-plt+ scale_colour_discrete(name  ="Batch")
    labs(x= "Normalized intensity", caption = "(based on Corrected Data/n parametric ComBat-model)") +
      theme_classic()
    p<- ggplot(g, aes(x = as.factor(g[, 1]), y = xx),drop.unused.levels = TRUE) +
      geom_violin(trim = FALSE, fill = "gray", color = "black") +
      geom_jitter(shape = 19, position = position_dodge(1)) +
      labs(x= "Batch", y= "Normalized intensity", title = colnames(g)[i + 1]) +
      geom_boxplot(width = 0.1)
    newfilename <- "originalData.csv"
    path_user <- dirname(file.path(tempdir(), newfilename))
    newfilepath <- file.path(path_user, newfilename)
    write.csv(m, newfilepath)
    newfilename <- "CorrectedData_parametricComBat.csv"
    newfilepath <- file.path(path_user, newfilename)
    write.csv(g, newfilepath)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#'
#'Profile Plot of Features (variables) in corrected data via  Non-Parametric ComBat
#'
#'It is a function in the \code{dbnorm}, a package in R. This function allows users to adjust the data for batch effect using non-parametric \emph{Empirical Bayes} approach (see "ComBat" in "sva", a package in bioconductor ). \emph{profplotpcom} visualize the result for global profile of each feature across batches via (\emph{Scatter} plot), (\emph{Violin} plot) and (\emph{Density (or pdf)} plot).\cr
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'@return Original and adjusted datasets in \bold{csv} format together with the series of profile plot of the features (variables) in the sample sets provided by \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into a \bold{PDF} file.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and/ or \code{emvd} implemented in the \code{dbnorm}. Input must be normalized and transformed prior.
#'@keywords profile plot Non parametric ComBat
#'@references Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034> \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#'@examples
#'\dontrun{
#'batch<- rep(gl(2,3,labels=(1:2)),2)
#'y<- matrix(rnorm(6000), nrow=12)
#'m<- data.frame (batch,y)
#'ProfPlotComNPara(m)
#'}
#'@export
ProfPlotComNPara<- function (m){
  origibal <- (m)
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=F);#parametric
  y<- t(com_p)
  g <- data.frame(m[, 1], y)
  colnames(g)[1] <- "Batch"
  pdf("ProfilePlot_nonparaComBatData.pdf")
  loop.vector <- 1:length(m[,-1])
  for (i in loop.vector) {
    x <- y[, i]
    xx <- g[, i + 1]
    n <- median(y[, i])
    std <- sd(y[, i])
    opar <- par(mfrow=c(3,1))
    on.exit(par(opar))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i + 1],drop.unused.levels = TRUE,
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    plt <- ggplot(g, aes(x = xx, colour = as.factor(g[,1])),drop.unused.levels = TRUE) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i + 1])
    dplot<-plt+ scale_colour_discrete(name  ="Batch")
    labs(x= "Normalized intensity", caption = "(based on Corrected Data/n non-parametric ComBat-model)") +
      theme_classic()
    p<- ggplot(g, aes(x = as.factor(g[, 1]), y = xx),drop.unused.levels = TRUE) +
      geom_violin(trim = FALSE, fill = "gray", color = "black") +
      geom_jitter(shape = 19, position = position_dodge(1)) +
      labs(x= "Batch", y= "Normalized intensity", title = colnames(g)[i + 1]) +
      geom_boxplot(width = 0.1)
    newfilename <- "originalData.csv"
    path_user <- dirname(file.path(tempdir(), newfilename))
    newfilepath <- file.path(path_user, newfilename)
    write.csv(m, newfilepath)
    newfilename <- "CorrectedData_NonparametricComBat.csv"
    newfilepath <- file.path(path_user, newfilename)
    write.csv(g, newfilepath)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#'
#'Drift Across Batch Normalization via ber- model and visualization
#'
#'It is a function in \code{dbnorm}, a package in R. This function allows users to effectively remove variance associated with batch from data by applying L/S method as explain by M.Giordan. In fact, in \emph{dbnormBer}, we included various types of graphical check for visualization of data point, sample-wise and feature-wise. Considering a single function as a correction algorithm, we aimed to fasten computational processing of big data. \cr Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R2} is considered to define the percentage of variance in a dependent variable estimated by independent variable (batch) in a original data (Raw data) and in corrected data. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notifies the consistency of model performance for all detected features (variables).\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'
#' @return  Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a \emph{correlation} plot estimated for raw and corrected data. Also, the \emph{RLA} plot for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and /or \code{emvd} implemented in the \code{'dbnorm'} package. Input must be normalized and transformed prior.
#'
#' @keywords  Unsupervised and regression analysis for normalized data via ber-model
#' @references
#' M.Giordan (2013) < DOI:10.1007/s12561-013-9081-1> \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom factoextra fviz_eig
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#' @examples
#' \dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'dbnormBer(m)}
#' @export
dbnormBer <- function(m){
  repos = getOption("repos")
  repos[c("ber","NormalizeMets")] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  colnames(m)[1]<-"Batch";
  y<- ber(as.matrix(m[,-1]),as.factor(m[,1]));#two-stage regression
  g<-data.frame(m[,1],y);
  p<-prcomp(m[,-1],scale=T)
  p.c<-prcomp(y,scale=T);
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]),drop.unused.levels = TRUE)
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.b<-sapply(2:ncol(g),function(i){
    fit.b <- lm(g[,i]~ as.factor(g[,1]),drop.unused.levels = TRUE)
    return( summary(fit.b)[["adj.r.squared"]])
  })
  pdf("dbnormBer_plot.pdf")
  pca<-fviz_pca_ind(p,label="none",habillage=m$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Raw Data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=m$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Corrected Data \n ber-model");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="RawData")
  sc.b<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3, main= "Corrected Data \n ber-model" )
  newfilename <- "mydata_berCorrected.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(g, newfilepath)
  rlp<-RlaPlots(m[,-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "Raw Data")
  rlp.b<-RlaPlots(y, m[,1],saveplot=T, savetype= "jpeg",plotname = "Corrected Data \n ber-model")
  p1<-plot(seq(along=corr), corr, xlab="Features",ylab="adj.R2", main="Raw Data")
  p2<-plot(seq(along=corr.b), corr.b, xlab="Features",ylab="adj.R2", main="Corrected Data\n ber-model")
  names(corr)<- names(m[-1])
  newfilename <- "RawData_adjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.b)<- names(m[-1])
  newfilename <- "berData_adjR2.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.b, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.b[1:length(corr.b)])
  as2<- sum(a2)
  am2<-max(a2)
  datm<-data.frame(Dataset=c("Raw","ber"),adjRSq=c(am1,am2));
  newfilename <- "SCore_MaxAdjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (Raw and Corrected)")
  pm<-pm + labs(y = "Maximum Adj.R2")
  pm<- pm + coord_flip()
  print(pca)
  print(pca.c)
  print(sc)
  print(sc.b)
  print(rlp)
  print(rlp.b)
  print(p1)
  print(p2)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}
#'Drift Across Batch Normalization applying ber-bagging model and visualization
#'
#'It is a function in \code{dbnorm}, a package in R. This function allows users to effectively remove variance associated with batch from data by applying L/S method and partial bagging with Bootstrap samples of size n=150, as explain by M.Giordan. In fact, in \emph{dbnormBagging}, we included various types of graphical check for visualization of data point, sample-wise and feature-wise. Considering a single function as a correction algorithm, we aimed to fasten computational processing of big data. \cr Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R2} is considered to define the percentage of variance in a dependent variable estimated by independent variable (batch) in a original data (Raw data) and in corrected data. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notifies the consistency of model performance for all detected features (variables).\cr
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'
#' @return  Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a \emph{correlation} plot estimated for raw and corrected data. Also, the \emph{RLA} plot for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and /or \code{emvd} implemented in the \code{'dbnorm'} package. Input must be normalized and transformed prior.
#'
#' @keywords  Unsupervised and regression analysis for normalized data via ber-model
#' @references
#' M.Giordan (2013) < DOI:10.1007/s12561-013-9081-1> \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom factoextra fviz_eig
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#' @examples
#' \dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'dbnormBagging(m)}
#' @export
dbnormBagging <- function(m){
  repos = getOption("repos")
  repos[c("ber","NormalizeMets")] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  colnames(m)[1]<-"Batch";
  y<- ber_bg(as.matrix(m[,-1]),as.factor(m[,1]),partial=TRUE,nSim=150);#two-stage regression
  g<-data.frame(m[,1],y);
  p<-prcomp(m[,-1],scale=T)
  p.c<-prcomp(y,scale=T);
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]),drop.unused.levels = TRUE)
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.b<-sapply(2:ncol(g),function(i){
    fit.b <- lm(g[,i]~ as.factor(g[,1]),drop.unused.levels = TRUE)
    return( summary(fit.b)[["adj.r.squared"]])
  })
  pdf("dbnormBagging_plot.pdf")
  pca<-fviz_pca_ind(p,label="none",habillage=m$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Raw Data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=m$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Corrected Data \n ber-bagging-model");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="RawData")
  sc.b<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3, main= "Corrected Data \n ber-bagging-model" )
  newfilename <- "mydata_ber_baggingCorrected.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(g, newfilepath)
  rlp<-RlaPlots(m[,-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "Raw Data")
  rlp.b<-RlaPlots(y, m[,1],saveplot=T, savetype= "jpeg",plotname = "Corrected Data \n ber-bagging-model")
  p1<-plot(seq(along=corr), corr, xlab="Features",ylab="adj.R2", main="Raw Data")
  p2<-plot(seq(along=corr.b), corr.b, xlab="Features",ylab="adj.R2", main="Corrected Data\n ber-bagging-model")
  names(corr)<- names(m[-1])
  newfilename <- "RawData_adjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.b)<- names(m[-1])
  newfilename <- "Ber-baggingData_adjR2.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.b, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.b[1:length(corr.b)])
  as2<- sum(a2)
  am2<-max(a2)
  datm<-data.frame(Dataset=c("Raw","ber-bagging"),adjRSq=c(am1,am2));
  newfilename <- "SCore_MaxAdjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (Raw and Corrected)")
  pm<-pm + labs(y = "Maximum Adj.R2")
  pm<- pm + coord_flip()
  print(pca)
  print(pca.c)
  print(sc)
  print(sc.b)
  print(rlp)
  print(rlp.b)
  print(p1)
  print(p2)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}
#'Drift Across Batch Normalization via Parametric- ComBat model and visualization
#'
#'It is a function in \code{dbnorm}, a package in R. This function allows you adjust the data for signal drift across multiple batches or batch effect applying emph{Empirical Bayes} method (see "ComBat" in "sva", a package in bioconductor ). Including single method in \emph{dbnormPcom}, we aimed to fasten the computational processing of big data. This function includes various types of graphical check for visualization of data point, sample-wise and feature-wise.\cr Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R2} is considered to define the percentage of variance in a dependent variable estimated by independent variable (batch) in a original data (Raw data) and in corrected data. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notifies the consistency of model performance for all detected features (variables).\cr
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'
#'@return Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a  \emph{correlation} plot for raw and corrected data. Also, the \emph{RLA} plots for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.
#'
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and /or \code{emvd} implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#'
#' @keywords  unsupervised analysis and regression for normalized data via ComBat-Parametric
#'@references Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034> \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom factoextra fviz_eig
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#' @examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'dbnormPcom(m)}
#' @export
dbnormPcom <- function(m){
  repos = getOption("repos")
  repos["NormalizeMets"] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  colnames(m)[1]<-"Batch";
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE, prior.plots=F);# nonparametric empirical Bayes
  pcom<-data.frame(m[1],t(com_p));
  p<-prcomp(m[,-1],scale=T)
  p.c<-prcomp(pcom[-1],scale=T);
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]),drop.unused.levels = TRUE)
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.pc<-sapply(2:ncol(pcom),function(i){
    fit.pc <- lm(pcom[,i]~ as.factor(pcom[,1]), drop.unused.levels = TRUE)
    return( summary(fit.pc)[["adj.r.squared"]])
  });
  pdf("dbnormParaComBat_Plot.pdf")
  pca<-fviz_pca_ind(p,label="Batch",habillage=m$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Raw Data");
  pca.c<-fviz_pca_ind(p.c,label="Batch",habillage=m$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Corrected Data \n parametricComBat-model");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="RawData")
  sc.pcom<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3, main= "Corrected Data \n parametric ComBat-model" )
  newfilename <- "mydata_parametricComBatCorrected.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(pcom, newfilepath)
  rlp<-RlaPlots(m[,-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "Raw Data")
  rlp.pcom<-RlaPlots(pcom[-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "Corrected Data \n parametricComBat-model")
  p1<-plot(seq(along=corr), corr, xlab="Features",ylab="adj.R2", main="Raw Data")
  p2<-plot(seq(along=corr.pc), corr.pc, xlab="Features",ylab="adj.R2", main="Corrected Data\n parametricComBat-model")
  names(corr)<- names(m[-1])
  newfilename <- "Rawdata_adjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.pc)<- names(m[-1])
  newfilename <- "parametricComBatData_adjR2.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.pc, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.pc[1:length(corr.pc)])
  as2<- sum(a2)
  am2<-max(a2)
  datm<-data.frame(Dataset=c("Raw","parametric ComBat "),adjRSq=c(am1,am2));
  newfilename <- "SCore_MaxAdjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (Raw and Corrected)")
  pm<-pm + labs(y = "Maximum Adj.R2")
  pm<- pm + coord_flip()
  print(pca)
  print(pca.c)
  print(sc)
  print(sc.pcom)
  print(rlp)
  print(rlp.pcom)
  print(p1)
  print(p2)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}
#'Drift Across Batch Normalization via non-Parametric ComBat model and visualization
#'
#'It is a function in \code{dbnorm}, a package in R. This function allows you adjust the data for signal drift across multiple batches or batch effect using non-parametric ComBat methods (see "ComBat" in "sva", a package in bioconductor ). Including single method in \emph{dbnormNPcom}, we aimed to fasten the computational processing of big data. This function includes various types of graphical check for visualization of data point, sample-wise and feature-wise.\cr Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R2} is considered to define the percentage of variance in a dependent variable estimated by independent variable (batch) in a original data (Raw data) and in corrected data. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notifies the consistency of model performance for all detected features (variables).\cr#'
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'
#'@return Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a  \emph{correlation} plot for raw and corrected dataset. Also, the \emph{RLA} plot for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.
#'
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and /or \code{emvd}, functions implemented in \code{'dbnorm'} package. Input must be normalized and transformed prior.
#'
#'@keywords  unsupervised analysis and regression for normalized data via ComBat NON-Parametric
#'
#'@references Johnson et al.(2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#'@examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'dbnormNPcom(m)}
#'
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 scale_colour_discrete
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom factoextra fviz_eig
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@importFrom ber ber_bg
#' @export
dbnormNPcom <- function(m){
  repos = getOption("repos")
  repos["NormalizeMets"] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  colnames(m)[1]<-"Batch";
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=F, prior.plots=F);# parametric empirical Bayes
  pcom<-data.frame(m[1],t(com_p));
  p<-prcomp(m[,-1],scale=T)
  p.c<-prcomp(pcom[-1],scale=T);
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]),drop.unused.levels = TRUE)
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.pc<-sapply(2:ncol(pcom),function(i){
    fit.pc <- lm(pcom[,i]~ as.factor(pcom[,1]), drop.unused.levels = TRUE)
    return( summary(fit.pc)[["adj.r.squared"]])
  });
  pdf("dbnormNonParaComBat_Plot.pdf")
  pca<-fviz_pca_ind(p,label="Batch",habillage=m$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Raw Data");
  pca.c<-fviz_pca_ind(p.c,label="Batch",habillage=m$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="Corrected Data \n non-parametricComBat-model");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="RawData")
  sc.pcom<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3, main= "Corrected Data \n non-parametric ComBat-model" )
  newfilename <- "mydata_nonparametricComBatCorrected.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(pcom, newfilepath)
  rlp<-RlaPlots(m[,-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "Raw Data")
  rlp.pcom<-RlaPlots(pcom[-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "Corrected Data \n non-parametricComBat-model")
  p1<-plot(seq(along=corr), corr, xlab="Features",ylab="adj.R2", main="Raw Data")
  p2<-plot(seq(along=corr.pc), corr.pc, xlab="Features",ylab="adj.R2", main="Corrected Data\n non-parametricComBat-model")
  names(corr)<- names(m[-1])
  newfilename <- "Rawdata_adjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.pc)<- names(m[-1])
  newfilename <- "nonParametricData_adjR2.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.pc, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.pc[1:length(corr.pc)])
  as2<- sum(a2)
  am2<-max(a2)
  datm<-data.frame(Dataset=c("Raw","non-parametric ComBat "),adjRSq=c(am1,am2));
  newfilename <- "SCore_MaxAdjR2.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (Raw and Corrected)")
  pm<-pm + labs(y = "Maximum Adj.R2")
  pm<- pm + coord_flip()
  print(pca)
  print(pca.c)
  print(sc)
  print(sc.pcom)
  print(rlp)
  print(rlp.pcom)
  print(p1)
  print(p2)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}
#'Hierarchical clustering analysis of original data and corrected data for batch effect
#'It is a function in \code{dbnorm}, a package in R. This function allows users to evaluate dissimilarity between identical samples (quality control replicates or analytical replicates) analyzed in different batches, prior and after correction using, ber, ber_bg and parametric and non-parametric ComBat . Pearson distance and average method for clustering were considered.
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'
#'@return Hierarchical clustering tree for original data (Raw data) and after correction, saved in a single \bold{PDF} file in a working directory and series of \bold{.csv} files includes distance values saved in temporary directory.
#'
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and /or \code{emvd} implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#'
#' @keywords hclust
#'@references Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034> \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#'@importFrom stats lm
#'@importFrom utils write.csv
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom factoextra get_dist
#'@importFrom stats hclust
#'@importFrom ber ber
#'@importFrom ber ber_bg
#'@examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'hclustdbnorm(m)}
#'
#' @export
hclustdbnorm <- function(m){
  repos = getOption("repos")
  repos[c("ber","NormalizeMets")] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos);
  colnames(m)[1]<-"Batch";
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
  com_n<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
  y<- ber(as.matrix(m[,-1]),as.factor(m[,1]));#two-stage regression
  yb<- ber_bg(as.matrix(m[,-1]),as.factor(m[,1]), partial=TRUE,nSim=150);#two-stage regression
  g<-data.frame(m[,1],y);
  gb<-data.frame(m[,1],yb);
  p.com<-data.frame(m[1],t(com_p));
  np.com<-data.frame(m[1],t(com_n));
  dist.cor.r <- get_dist(m[-1], method = "pearson");
  df.r<-as.matrix(dist.cor.r)
  hp.r <- hclust( dist.cor.r, method="average")
  dist.cor.b <- get_dist(g[-1], method = "pearson");
  df.b<-as.matrix(dist.cor.b)
  hp.b <- hclust( dist.cor.b, method="average")
  dist.cor.bg <- get_dist(gb[-1], method = "pearson");
  df.bg<-as.matrix(dist.cor.bg)
  hp.bg <- hclust( dist.cor.bg, method="average")
  dist.cor.pc <- get_dist(p.com[-1], method = "pearson");
  df.pc<-as.matrix(dist.cor.pc)
  hp.pc <- hclust( dist.cor.pc, method="average")
  dist.cor.npc <- get_dist(np.com[-1], method = "pearson");
  df.n.pc<-as.matrix(dist.cor.npc)
  hp.npc <- hclust( dist.cor.npc, method="average")
  pdf("hclustdbnorm.pdf")
  p.h.r<-plot(hp.r, hang=-1, labels=as.character(rownames(m)), cex=0.6, main="RawData",cex.main=0.9, cex.lab=0.9, cex.axis=0.75,
              xlab = "1-p")

  p.h.b<-plot(hp.b, hang=-1, labels=as.character(rownames(g)), cex=0.6, main="Corrected Data\n ber-model",cex.main=0.9, cex.lab=0.9, cex.axis=0.75,
              xlab = "1-p")

  p.h.bg<-plot(hp.bg, hang=-1, labels=as.character(rownames(gb)), cex=0.6, main="Corrected Data\n ber-bagging-model",cex.main=0.9, cex.lab=0.9, cex.axis=0.75,
               xlab = "1-p")
  p.h.pc<-plot(hp.pc, hang=-1, labels=as.character(rownames(p.com)), cex=0.6, main="Corrected Data\n parametric ComBat-model",cex.main=0.9, cex.lab=0.9, cex.axis=0.75,
               xlab = "1-p")
  p.h.npc<-plot(hp.npc, hang=-1, labels=as.character(rownames(np.com)), cex=0.6, main="Corrected Data\n non-parametric ComBat-model",cex.main=0.9, cex.lab=0.9, cex.axis=0.75,
                xlab = "1-p")
  newfilename <- "Distance_RawData.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(df.r, newfilepath)
  newfilename <- "Distance_berData.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(df.b, newfilepath)
  newfilename <- "Distance_ber_baggingData.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(df.bg, newfilepath)
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilename <- "Distance_parametricComBatData.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(df.pc, newfilepath)
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilename <- "Distance_nonparametricComBatData.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(df.n.pc, newfilepath)
  print(p.h.r)
  print(p.h.b)
  print(p.h.bg)
  print(p.h.pc)
  print(p.h.npc)
  dev.off()
}
