# dbnorm 0.2.1

* Added a `NEWS.md` file to track changes to the package.
2
