#' Visualization and normalization of signal drift across batches\cr
#'
#'  This function performs batch effect adjustment via three statistical models, namely two-stage procedure as described by M. Giordan (2013) < DOI:10.1007/s12561-013-9081-1> (see also "ber" ) and/or empirical Bayes methods in two setting of parametric and non-parametric as described by  Johnson et al., (2007) < DOI: 10.1093/biostatistics/kxj037 > ( see "comBat" in "sva", a package in bioconductor) . Meanwhile, the graphical inferences in the context of unsupervised learning algorithms create visual inspection to inform users about the spatial separation of the sample sets analyzed in the different analytical runs alongside the distribution of the features (variables) in the sample sets and across multiple batches.\cr
#'@param f A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by \code{emvf} and /or \code{emvd}, functions implemented in the \code{dbnorm} package. Input data must be normalized prior.
#'@return  Three datasets, adjusted by either of applied statistical algorithms prepared in \bold{csv} and together with series of plot such as \emph{PCA} plot and \emph{Scree plot} compiled into a \bold{PDF} file are saved in the working directory. \emph{RLA} plots are represented in the \bold{Viewer} panel of \bold{rstudio}.
#'@keywords Visualization and across batch normalization
#'
#'@references M.Giordan (2013) < DOI:10.1007/s12561-013-9081-1 > \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}\cr
#'Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037>  \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@examples
#'\dontrun{
#'Visdbnorm
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'f<-data.frame(batch,y)
#'Visdbnorm(f)}
#'
#'@export
Visdbnorm<- function(f){
  repos = getOption("repos")
  repos[c("ber","NormalizeMets")] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  com_p<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
  com_n<- ComBat(t(as.matrix(f[,-1])),as.factor(f[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
  colnames(f)[1]<-"Batch";
  y<- ber(as.matrix(f[,-1]),as.factor(f[,1]));#two-stage regression
  m_p<- data.frame(f[1],t(com_p));
  m_n<- data.frame(f[1],t(com_n));
  pdf("dbnorm_plot.pdf")
  p<-prcomp(f[,-1],center=T,scale=T)
  p.c<-prcomp(y,center=T,scale=T);
  p.c_p<-prcomp(m_p[-1],center=T,scale=T);
  p.c_n<-prcomp(m_n[-1],center=T,scale=T);
  pca<-fviz_pca_ind(p,label="none",habillage=f$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="PCA-raw");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="PCA-ber-corrected");
  pca.p<-fviz_pca_ind(p.c_p,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="PCA-combatParametric-corrected");
  pca.n<-fviz_pca_ind(p.c_n,label="none",habillage=f$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="PCA-combatNonparametric-corrected");
  sp<- screeplot(p, type = "l", npcs = 10, main = " First 10 PCs_raw",ylim=c(0,100))
  abline(h = 1, col="red", lty=5)
  labs(title ="raw-data",x = "PC", y = "Variance")
  legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
  sp.cor<- screeplot(p.c, type = "l", npcs = 10, main = "First 10 PCs-ber")
  abline(h = 1, col="red", lty=5)
  labs(title ="ber-data",x = "PC", y = "Variance")
  legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
  sp.p<- screeplot(p.c_p, type = "l", npcs = 10, main = "First 10 10 PCs-ComBatParametric")
  abline(h = 1, col="red", lty=5)
  labs(title ="ComBat-Parametric",x = "PC", y = "Variance")
  legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
  sp.n<- screeplot(p.c_n, type = "l", npcs = 10, main = "First 10 PCs-ComBatNParametric")
  abline(h = 1, col="red", lty=5)
  labs(title ="ComBat-NonParametric",x = "PC", y = "Variance")
  legend("topright", legend=c("Eigenvalue = 1"),col=c("red"), lty=5, cex=0.6) ;
  g<-data.frame(f[1],y)
  newfilename <- "myresult_ber.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(g, newfilepath)
  newfilename <- "myresult_ParametricCombat.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(m_p, newfilepath)
  newfilename <- "myresult_NonParametricCombat.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(m_n, newfilepath)
  rlp<-RlaPlots( f[,-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_raw")
  rlp.c<-RlaPlots( y, f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_Ber")
  rlp.p<-RlaPlots( m_p[-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ComBatParametric")
  rlp.n<-RlaPlots( m_n[-1], f[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ComBatNonParametric")
  opar <- par(mfrow=c(8,1))
  on.exit(par(opar))
  print(sp)
  print(sp.cor)
  print(sp.p)
  print(sp.n)
  print(pca)
  print(pca.c)
  print(pca.p)
  print(pca.n)
  print(rlp)
  print(rlp.c)
  print(rlp.p)
  print(rlp.n)
  dev.off()
}
#'Estimation of missing value feature-based
#'
#'This is a function in the \code{dbnorm}, a package in R. This function returns to a matrix of data in which missing values (Zero and/or NA values) are estimated. By this function, all Zero values are first replaced by NA values, which are then replaced by the lowest detected value on the column margin.\cr
#'@param m An array or a matrix
#'@keywords Missing value estimation
#'@details empty entries are not allowed
#'@return A matrix with estimated missing value.
#'@examples
#'m<- data.frame(x1=c(50,NA,6,10,30),x2=c(2,8,NA,15,0))
#'emvf(m)
#'@export
emvf <-function(m){
  apply(m, 2, function (x) {
    x[x == 0] <- NA;
    x<-as.numeric(as.character(x))
    x[is.na(x)] = min(x[x >0], na.rm=TRUE)
    x
  }
  )
}
#'Estimation of missing value data-based
#'
#'This is a function in the \code{dbnorm}, a package in R. It returns to a matrix of data in which missing values are estimated by the lowest detected value in the entire experiment. By this function, all NA values are replaced by Zero values, that of being ultimately replaced by the lowest value detected in the experiment. Ultimately, data matrix is transposed to restore original structure.\cr
#'
#' @param m An array or a matrix
#' @keywords Missing value estimation
#' @details empty entries are not allowed
#' @return  A matrix with estimated missing value.
#'@examples
#' m<- data.frame(x1=c(50,NA,6,10,30),x2=c(2,8,NA,15,0))
#' emvd(m)
#'
#' @export
emvd<- function(m){
  apply (m, 2,function(x){
    is.na(m) <- !m
    min.val = min(m, na.rm = T)
    x[is.na(x)]<-min.val
    x[x == 0] <- min.val;

    x
  }
  )
}
#'
#'Adjusted Coefficient Of Determination for a data normalized for signal drift across batches\cr
#'
#'It is a function in \code{dbnorm}, a package in R. This function gives a quick notification about the performance of the compiled statistical models namely two-stage regression procedure (see "ber" function and its package in R) and/or empirical Bayes methods in two setting of parametric and non-parametric ( see "ComBat" in "sva", a package in bioconductor), on accommodation of batch effect. Using this function users will estimate values of adjusted coefficient of determination ( Adjusted R- Squared ) which address the dependency of each feature (variable) to the batch order in each dataset. Immediately, a score calculated based on the maximum variability estimated by the regression analysis has been calculated and printed. This score notifies the consistency of a model performance for the detected features (variables), facilitating quick comparison of the models for selecting one of those models, which is more appropriate to the data structure.\cr
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by \code{emvf} or \code{emvd}, functions implemented in \code{dbnorm} package. Input data must be normalized prior.
#'@return  Several graphs compiled into a \bold{PDF} file which are a \emph{correlation} plot for each of applied models, a grouped \emph{barplot} presenting the maximum variability associated with batch levels in the raw and the corrected datasets.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected via either of applied models. Also, a two column matrix for Adjusted R-Square for raw and corrected datasets and a table summarizing the score values presented in \emph{barplot}.
#'@keywords Adjusted R-squared
#'@references Giordan (2013) < DOI:10.1007/s12561-013-9081-1 > \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}\cr
#'Johnson et al., (2007) < DOI: 10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034 >  \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'ACDdbnorm(m)}
#'
#'@export
ACDdbnorm <- function(m){
  repos = getOption("repos")
  repos[c("ber","NormalizeMets")] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos);
  colnames(m)[1]<-"Batch";
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
  com_n<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=FALSE, prior.plots=F)# non parametric empirical Bayes
  y<- ber(as.matrix(m[,-1]),as.factor(m[,1]));#two-stage regression
  g<-data.frame(m[,1],y);
  pcom<-data.frame(m[1],t(com_p));
  npcom<-data.frame(m[1],t(com_n));
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]))
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.b<-sapply(2:ncol(g),function(i){
    fit.b <- lm(g[,i]~ as.factor(g[,1]))
    return( summary(fit.b)[["adj.r.squared"]])
  })
  corr.cp<-sapply(2:ncol(pcom),function(i){
    fit.cp <- lm(pcom[,i]~ as.factor(m[,1]))
    return( summary(fit.cp)[["adj.r.squared"]])
  });

  corr.ncp<-sapply(2:ncol(npcom),function(i){
    fit.ncp <- lm(npcom[,i]~ as.factor(m[,1]))
    return( summary(fit.ncp)[["adj.r.squared"]])
  })
  wd <- tempdir()
  pdf("AdjRSQ_plot.pdf")
  p1<-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.square", main="rawData")
  p2<-plot(seq(along=corr.b), corr.b, xlab="variable",ylab="adj.r.square", main="ber-corrected")
  p3<-plot(seq(along=corr.cp), corr.cp, xlab="variable",ylab="adj.r.square", main="parComBat-corrected")
  p4<-plot(seq(along=corr.ncp), corr.ncp, xlab="variable",ylab="adj.r.square", main="nonpar-ComBat-corrected")
  names(corr)<- names(m[-1])
  newfilename <- "rawdata_adjustedRsquare.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.b)<- names(m[-1])
  newfilename <- "berdata_adjRsquare.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.b, newfilepath)
  names(corr.cp)<- names(m[-1])
  newfilename <- "ParaComBat_adjRsquare.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.cp, newfilepath)
  names(corr.ncp)<- names(m[-1])
  newfilename <- "NonParaComBat_adjRsquare.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.ncp, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.b[1:length(corr.b)])
  as2<- sum(a2)
  am2<-max(a2)
  a3<- abs (corr.cp[1:length(corr.cp)])
  as3<-sum(a3)
  am3<-max(a3)
  a4<-abs (corr.ncp[1:length(corr.ncp)])
  as4<-sum(a4)
  am4<-max(a4)
  datm<-data.frame(Dataset=c("Raw","npcom","pcom","ber"),adjRSq=c(am1,am4,am3,am2));
  newfilename <- "SCore_MaxdjRSq.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (raw and Model-corrected)")
  pm<-pm + labs(y = "Maximum Adjusted R-squared")
  pm<- pm + coord_flip()
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}
#'
#'
#'Profile Plot of Features (variables) in raw data
#'
#' It is a function in the \code{dbnorm} This function informs you about the presence of across batch signal drift or batch effect in the raw data determined by the shifted probability density function plots (\emph{pdf} plots) of features (variables) detected in an experiment.\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch level in the first column.
#' @return Original dataset in \bold{csv} format together with the series of profile plot for the features (variables) in the sample sets analyzed in the entire experiment provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into \bold{PDF} file.\cr
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by functions such as \code{emvf} or \code{emvd} Compiled in the \code{'dbnorm'} package. Input must be normalized and transformed prior.
#' @keywords raw data profile plot
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'
#' @examples
#' \dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5),1))
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'profplotraw(m)
#'}
#'@export
profplotraw <- function (m){
  origibal <- (m)
  colnames(m)[1] <- "Batch"
  pdf("ProfilePlot_RawData.pdf")
  loop.vector <- 1:length(m[, -1])
  for (i in loop.vector) {
    x <- m[, i + 1]
    n <- median(m[, i + 1])
    std <- sd(m[, i + 1])
    par(mfrow = c(3, 1))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i +1],
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    dplot <- ggplot(m, aes(x = x, colour = as.factor(m[,1]))) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i +1]) +
      labs(x="Batch", caption = "(based on Raw_Data)") + theme_classic()
    p<- ggplot(m, aes(x = as.factor(m[, 1]), y = x)) +
      geom_violin(trim = FALSE,
                  fill = "gray", color = "black") +
      geom_jitter(shape = 19,position = position_dodge(1)) +
      labs(x="Batch",y="Normalized intensity", title = colnames(m)[i +1]) +
      geom_boxplot(width = 0.1)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#'
#' Profile Plot of Features (variables) in ber- corrected data
#'
#'It is a function in the \code{dbnorm}, a package in R. This function allows you to adjust the data for batch effect using two-stage procedure approach ( see also "ber" function and its package in R ) and informs you about the presence of batch effect or changes in the profile of detected features (variables) in the corrected data, determined by the shifted probability density function plots (\emph{pdf} plots).\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#' @return Original and adjusted datasets in \bold{csv} format together with the series of profile plot for the variables( features) in the sample sets analyzed in the entire experiment provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into \bold{PDF} file.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and/ or \code{emvd} implemented in the \code{dbnorm}. Input must be normalized and transformed prior.
#' @keywords ber correction and profile plot
#' @references M.Giordan (2013) < DOI:10.1007/s12561-013-9081-1 > \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#' @examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5),1))
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'profplotber(m)
#'}
#' @export
profplotber<- function (m){
  repos = getOption("repos")
  repos["ber"] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  origibal <- (m)
  y <- ber(as.matrix(m[, -1]), as.factor(m[, 1]))
  g <- data.frame(data.frame(m[, 1], y))
  colnames(g)[1] <- "Batch"
  pdf("ProfilePlot_berCorrected.pdf")
  loop.vector <- 1:length(m[, -1])
  for (i in loop.vector) {
    x <- y[, i]
    xx <- g[, i + 1]
    n <- median(y[, i])
    std <- sd(y[, i])
    opar <- par(mfrow=c(3,1))
    on.exit(par(opar))
    myplot <- plot(m[, 1], x, col = "black", main = colnames(m)[i + 1],
                   xlab = "Batch", ylab = "Normalized intensity")
    abline(h = n, col = "gray", lty = 1)
    abline(h = n + std, lty = 2, col = "gray")
    abline(h = n - std, lty = 2, col = "gray")
    lines(lowess(m[, 1], x), col = "red4")
    dplot <- ggplot(g, aes(x = xx, colour = as.factor(g[,1]))) +
      geom_density() + theme_bw() + ggtitle(colnames(m)[i + 1]) +
      labs(x= "Normalized intensity", caption = "(based on ber- Corrected)") +
      theme_classic()
    p<- ggplot(g, aes(x = as.factor(g[, 1]), y = xx)) +
      geom_violin(trim = FALSE, fill = "gray", color = "black") +
      geom_jitter(shape = 19, position = position_dodge(1)) +
      labs(x= "Batch", y= "Normalized intensity", title = colnames(g)[i + 1]) +
      geom_boxplot(width = 0.1)
    newfilename <- "originalDataset.csv"
    path_user <- dirname(file.path(tempdir(), newfilename))
    newfilepath <- file.path(path_user, newfilename)
    write.csv(m, newfilepath)
    newfilename <- "ber_corrected_data.csv"
    newfilepath <- file.path(path_user, newfilename)
    write.csv(g, newfilepath)
    print(p)
    print(myplot)
    print(dplot)
  }
  dev.off()
}
#' Profile Plot of Features (variables) in corrected data via  Parametric ComBat
#'
#'It is a function in the \code{dbnorm}, a package in R. This function allows users to adjust the data for batch effect using Parametric Empirical Bayes approach ( see "ComBat" in "sva", a package in bioconductor ). \emph{profplotpcom} informs users about the presence of batch effect or changes in the profile of detected features (variables) in the corrected data, determined by the shifted probability density function plots (\emph{pdf} plots).\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#' @return Original and adjusted datasets in \bold{csv} format together with the series of profile plot for the features(variables) in the sample sets provided by the \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into a \bold{PDF} file.
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and/ or \code{emvd} implemented in the \code{'dbnorm'}. Input must be normalized and transformed prior.
#'@keywords Parametric ComBat and profile plot
#'@references Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034> \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'
#' @examples
#' \dontrun{
#'batch<- rep(gl(2,3,labels=(1:2)),2)
#'y<- matrix(rnorm(6000), nrow=12)
#'m<- data.frame (batch,y)
#'profplotpcom(m)
#'}
#' @export
profplotpcom<- function(m){
  origibal<-(m);
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE);#parametric
  y<- t(com_p)
  g<- data.frame(m[,1],y);
  colnames(g)[1] <- "Batch"
  pdf('ProfilePlot_PComBat.pdf')
  loop.vector<- 1:length(m[,-1]);
  for (i in loop.vector){
    x<- y[,i]
    xx<-g[,i+1]
    n<-median(y[,i])
    std<-sd(y[,i])
    opar <- par(mfrow=c(3,1))
    on.exit(par(opar))
    myplot<-plot(m[,1],x,col = "black",main=colnames(m)[i+1],xlab="Batch",ylab = "Normalized intensity")
    abline(h=n,col = "gray", lty = 1)
    abline(h=n+std,lty = 2,col = "gray")
    abline(h=n-std,lty = 2,col = "gray")
    lines(lowess(m[,1],x),col="red4")
    dplot<-ggplot(g, aes(x=xx, colour=as.factor(g[,1]))) +
      geom_density()+theme_bw()+ggtitle(colnames(m)[i+1])+
      labs(x=" Normalized intensity", caption = "(based on Parametric ComBat-corrected)")+
      theme_classic()
    p<- ggplot(g, aes(x=as.factor(g[,1]), y=xx)) +
      geom_violin(trim=FALSE, fill='gray', color="black")+geom_jitter(shape=19,position=position_dodge(1))+
      labs(x="Batch", y="Normalized intensity", title=colnames(g)[i+1])+geom_boxplot(width=0.1)
    newfilename <- "originalDataset.csv"
    path_user <- dirname(file.path(tempdir(), newfilename))
    newfilepath <- file.path(path_user, newfilename)
    write.csv(m, newfilepath)
    newfilename <- "ParaComBatData.csv"
    newfilepath <- file.path(path_user, newfilename)
    write.csv(g, newfilepath)
    print(p)
    print(myplot)
    print(dplot)

  }
  dev.off()
}
#'
#'Profile Plot of Features (variables) in corrected data via  NonParametric ComBat
#'
#'It is a function in the \code{dbnorm}, a package in R. This function allows users to adjust the data for batch effect based on Non-Parametric Empirical Bayes approach (see "ComBat" function in "sva", a package in bioconductor ). \emph{profplotnpcom} informs users about the presence of batch effect or changes in the profile of detected features (variables) in the corrected data, determined by the shifted probability density function plots (\emph{pdf} plots).\cr
#'
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'@return Original and adjusted datasets in \bold{csv} format together with the series of profile plot of the features (variables) in the sample sets provided by \emph{Scatter} plot,\emph{Violin} plot and \emph{pdf} plot compiled into a \bold{PDF} file.
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and/ or \code{emvd} implemented in the \code{dbnorm}. Input must be normalized and transformed prior.
#'@keywords profile plot Non parametric ComBat
#'@references Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034> \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#'@examples
#'\dontrun{
#'batch<- rep(gl(2,3,labels=(1:2)),2)
#'y<- matrix(rnorm(6000), nrow=12)
#'m<- data.frame (batch,y)
#'profplotnpcom(m)
#'}
#'@export
profplotnpcom<- function(m){
  origibal<-(m);
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=F);#parametric
  y<- t(com_p)
  g<- data.frame(m[,1],y);
  colnames(g)[1] <- "Batch"
  pdf('ProfilePlot_NPComBat.pdf')
  loop.vector<- 1:length(m[,-1]);
  for (i in loop.vector){
    x<- y[,i]
    xx<-g[,i+1]
    n<-median(y[,i])
    std<-sd(y[,i])
    opar <- par(mfrow=c(3,1))
    on.exit(par(opar))
    myplot<-plot(m[,1],x,col = "black",main=colnames(m)[i+1],xlab="Batch",ylab = "Normalized intensity")
    abline(h=n,col = "gray", lty = 1)
    abline(h=n+std,lty = 2,col = "gray")
    abline(h=n-std,lty = 2,col = "gray")
    lines(lowess(m[,1],x),col="red4")
    dplot<-ggplot(g, aes(x=xx, colour=as.factor(g[,1]))) +
      geom_density()+theme_bw()+ggtitle(colnames(m)[i+1])+
      labs(x=" Normalized intensity", caption = "(based on nonParametric ComBat-corrected)")+
      theme_classic()
    p<- ggplot(g, aes(x=as.factor(g[,1]), y=xx)) +
      geom_violin(trim=FALSE, fill='gray', color="black")+geom_jitter(shape=19,position=position_dodge(1))+
      labs(x="Batch", y="Normalized intensity", title=colnames(g)[i+1])+geom_boxplot(width=0.1)
    newfilename <- "originalDataset.csv"
    path_user <- dirname(file.path(tempdir(), newfilename))
    newfilepath <- file.path(path_user, newfilename)
    write.csv(m, newfilepath)
    newfilename <- "nonParComBatData.csv"
    newfilepath <- file.path(path_user, newfilename)
    write.csv(g, newfilepath)
    print(p)
    print(myplot)
    print(dplot)

  }
  dev.off()
}
#'
#'Drift Across Batch Normalization via ber- model and visualization
#'
#'It is a function in \code{dbnorm}, a package in R. This function allows you to adjust the data for signal drift across multiple batches or batch effect using two-stage procedure approach ( see "ber" ).\emph{dbnormBer} includes advanced statistical tools to inspect the structure and quality of high throughput experiment both in macroscopic and microscopic scales at the level of sample sets and metabolic feature, respectively. Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R squared} is considered to define the level of dependency of feature ( variable) to the batch level in the raw and corrected datasets. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notify the consistency of model performance for all detected features (variables).\cr
#'
#' @param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'
#' @return  Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a \emph{correlation} plot estimated for raw and corrected data. Also, the \emph{RLA} plot for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and /or \code{emvd} implemented in the \code{'dbnorm'} package. Input must be normalized and transformed prior.
#'
#' @keywords  Unsupervised and regression analysis for normalized data via ber-model
#' @references
#' M.Giordan (2013) < DOI:10.1007/s12561-013-9081-1> \emph{https://link.springer.com/article/10.1007/s12561-013-9081-1}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom factoextra fviz_eig
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#' @examples
#' \dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'dbnormBer(m)}
#' @export
dbnormBer <- function(m){
  repos = getOption("repos")
  repos[c("ber","NormalizeMets")] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  colnames(m)[1]<-"Batch";
  y<- ber(as.matrix(m[,-1]),as.factor(m[,1]));#two-stage regression
  g<-data.frame(m[,1],y);
  p<-prcomp(m[,-1],scale=T)
  p.c<-prcomp(y,scale=T);
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]))
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.b<-sapply(2:ncol(g),function(i){
    fit.b <- lm(g[,i]~ as.factor(g[,1]))
    return( summary(fit.b)[["adj.r.squared"]])
  })


  pdf("dbnormBer_plot.pdf")
  pca<-fviz_pca_ind(p,label="none",habillage=m$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=m$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="ber data");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_rawData")
  sc.b<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_berData")
  newfilename <- "mydata_berCorrected.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(g, newfilepath)
  rlp<-RlaPlots( m[,-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_raw")
  rlp.b<-RlaPlots( y, m[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ber")
  p1<-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.square", main="rawData")
  p2<-plot(seq(along=corr.b), corr.b, xlab="variable",ylab="adj.r.square", main="ber-corrected")
  names(corr)<- names(m[-1])
  newfilename <- "rawdata_adjustedRsquare.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.b)<- names(m[-1])
  newfilename <- "berdata_adjRsquare.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.b, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.b[1:length(corr.b)])
  as2<- sum(a2)
  am2<-max(a2)
  datm<-data.frame(Dataset=c("raw","ber"),adjRSq=c(am1,am2));
  newfilename <- "SCore_MaxdjRSq.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (raw and Model-corrected)")
  pm<-pm + labs(y = "Maximum Adjusted R-squared")
  pm<- pm + coord_flip()
  print(pca)
  print(pca.c)
  print(sc)
  print(sc.b)
  print(rlp)
  print(rlp.b)
  print(p1)
  print(p2)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}
#'Drift Across Batch Normalization via Parametric- ComBat model and visualization
#'
#'It is a function in \code{dbnorm}, a package in R. This function allows you adjust the data for signal drift across multiple batches or batch effect via parametric Empirical Bayes approach ( see "ComBat" in "sva", a package in bioconductor ). \emph{dbnormPcom}  includes advanced statistical tools to inspect the structure and quality of high throughput experiment both in macroscopic and microscopic scales at the level of sample sets and metabolic feature, respectively. Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R squared} is considered to define the level of dependency of feature (variable) to the batch level in the raw and corrected datasets. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notify the consistency of model performance for all detected features (variables).\cr
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch levels in the first column.
#'
#'@return Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a  \emph{correlation} plot for raw and corrected data. Also, the \emph{RLA} plots for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.
#'
#'
#' @details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and /or \code{emvd} implemented in \code{dbnorm} package. Input must be normalized and transformed prior.
#'
#' @keywords  unsupervised analysis and regression for normalized data via ComBat-Parametric
#'@references Johnson et al., (2007) < DOI:10.1093/biostatistics/kxj037 > \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al., (2012) < DOI:10.1093/bioinformatics/bts034> \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom factoextra fviz_eig
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#' @examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'dbnormPcom(m)}
#' @export
dbnormPcom<- function(m){
  repos = getOption("repos")
  repos["NormalizeMets"] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  colnames(m)[1]<-"Batch";
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=TRUE, prior.plots=F);# parametric empirical Bayes
  pcom<-data.frame(m[1],t(com_p));
  p<-prcomp(m[,-1],scale=T)
  p.c<-prcomp(pcom[-1],scale=T);
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]))
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.pc<-sapply(2:ncol(pcom),function(i){
    fit.pc <- lm(pcom[,i]~ as.factor(pcom[,1]))
    return( summary(fit.pc)[["adj.r.squared"]])
  })
  pdf("dbnormPComBat_plot.pdf")
  pca<-fviz_pca_ind(p,label="none",habillage=m$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=m$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="ParametricComBat data");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_rawData")
  sc.pcom<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_ParametricCombatData")
  newfilename <- "mydata_ParametricComBatCorrected.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(pcom, newfilepath)
  rlp<-RlaPlots( m[,-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_raw")
  rlp.pcom<-RlaPlots( pcom[-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_ParametricComBat")
  p1<-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.square", main="rawData")
  p2<-plot(seq(along=corr.pc), corr.pc, xlab="variable",ylab="adj.r.square", main="ParametricComBat-corrected")
  names(corr)<- names(m[-1])
  newfilename <- "rawdata_adjustedRsquare.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.pc)<- names(m[-1])
  newfilename <- "ParametricComBatdata_adjRsquare.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.pc, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.pc[1:length(corr.pc)])
  as2<- sum(a2)
  am2<-max(a2)
  datm<-data.frame(Dataset=c("raw","ParametricComBat"),adjRSq=c(am1,am2));
  newfilename <- "SCore_MaxdjRSq.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (raw and Model-corrected)")
  pm<-pm + labs(y = "Maximum Adjusted R-squared")
  pm<- pm + coord_flip()
  print(pca)
  print(pca.c)
  print(sc)
  print(sc.pcom)
  print(rlp)
  print(rlp.pcom)
  print(p1)
  print(p2)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}

#'Drift Across Batch Normalization via Parametric- ComBat model and visualization
#'
#'It is a function in \code{dbnorm}, a package in R. This function allows you to adjust the data for signal drift across multiple batches or batch effect via non-parametric Empirical Bayes approach ( see "sva", a package in bioconductor). \emph{dbnormNPcom} includes advanced statistical tools to inspect the structure and quality of high throughput experiment both in macroscopic and microscopic scales at the level of sample sets and metabolic feature, respectively. Notably, using this function users applied unsupervised learning algorithm to visualize the most variance explained by the two first components in the different set of samples analyzed in the entire experiment in the raw and corrected data. In parallel, linear association of feature (variable) and batch level has been estimated and visualized by a correlation plot. In fact, estimated \emph{Adjusted- R squared} is considered to define the level of dependency of feature (variable) to the batch level in the raw and corrected datasets. Besides, for quick notification about the performance of the applied model a maximum variability detected in either of datasets is reported as a score. This score notify the consistency of model performance for all detected features (variables).\cr
#'
#'@param m A data frame in which rows define the independent experiments (samples) and columns the features (variables), with the batch in the first column.
#'
#'@return Several graphs compiled into a \bold{PDF} file are a \emph{PCA} score plot, \emph{Scree} plot and a  \emph{correlation} plot for raw and corrected dataset. Also, the \emph{RLA} plot for each dataset visualized in the \bold{Viewer} panel in the \bold{rstudio} console.\cr
#'Files saved as \bold{csv} in the working directory are a dataset corrected by the applied model. Also, a two column matrix for Adjusted R-Square raw and corrected dataset and a table summarizing the maximum score.
#'
#'@details Zero and NA values are not allowed. Optionally missing value can be imputed by the functions such as \code{emvf} and /or \code{emvd}, functions implemented in \code{'dbnorm'} package. Input must be normalized and transformed prior.
#'
#'@keywords  unsupervised analysis and regression for normalized data via ComBat NON-Parametric
#'
#'@references Johnson et al.(2007) \emph{http://www.ncbi.nlm.nih.gov/pubmed/16632515}\cr
#'Leek et al. (2012) \emph{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3307112/}
#'
#'
#'@examples
#'\dontrun{
#'batch<- rep(gl(5,10,labels = c(1:5)),1)
#'y<- matrix(rnorm(5000),nrow=50)
#'m<-data.frame(batch,y)
#'dbnormNPcom(m)}
#'
#'@importFrom stats lowess
#'@importFrom stats lm
#'@importFrom stats median
#'@importFrom stats prcomp
#'@importFrom stats reorder
#'@importFrom stats screeplot
#'@importFrom stats sd
#'@importFrom utils write.csv
#'@importFrom graphics abline
#'@importFrom graphics legend
#'@importFrom graphics lines
#'@importFrom graphics par
#'@importFrom graphics plot
#'@importFrom grDevices dev.off
#'@importFrom grDevices pdf
#'@importFrom sva ComBat
#'@importFrom ggplot2 coord_flip
#'@importFrom ggplot2 aes
#'@importFrom ggplot2 geom_bar
#'@importFrom ggplot2 theme_classic
#'@importFrom ggplot2 labs
#'@importFrom factoextra fviz_pca_ind
#'@importFrom factoextra fviz_eig
#'@importFrom ggplot2 ggplot
#'@importFrom ggplot2 geom_density
#'@importFrom ggplot2 theme_bw
#'@importFrom ggplot2 ggtitle
#'@importFrom ggplot2 geom_violin
#'@importFrom ggplot2 geom_jitter
#'@importFrom ggplot2 position_dodge
#'@importFrom ggplot2 geom_boxplot
#'@importFrom NormalizeMets RlaPlots
#'@importFrom ber ber
#' @export
dbnormNPcom<- function(m){
  repos = getOption("repos")
  repos["NormalizeMets"] = "http://cran.us.r-project.org"
  options(repos = repos)
  invisible(repos)
  colnames(m)[1]<-"Batch";
  com_p<- ComBat(t(as.matrix(m[,-1])),as.factor(m[,1]),par.prior=FALSE, prior.plots=F);# parametric empirical Bayes
  pcom<-data.frame(m[1],t(com_p));
  p<-prcomp(m[,-1],scale=T)
  p.c<-prcomp(pcom[-1],scale=T);
  corr <- sapply(2:ncol(m),function(i){
    fit <- lm(m[,i]~ as.factor(m[,1]))
    return( summary(fit)[["adj.r.squared"]])
  });
  corr.pc<-sapply(2:ncol(pcom),function(i){
    fit.pc <- lm(pcom[,i]~ as.factor(pcom[,1]))
    return( summary(fit.pc)[["adj.r.squared"]])
  })
  pdf("dbnormNPComBat_plot.pdf")
  pca<-fviz_pca_ind(p,label="none",habillage=m$Batch,
                    addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="raw data");
  pca.c<-fviz_pca_ind(p.c,label="none",habillage=m$Batch,
                      addEllipses=TRUE, ellipse.level=0.95)+
    labs(title ="NonParametricComBat data");
  sc<- fviz_eig(p, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_rawData")
  sc.pcom<- fviz_eig(p.c, addlabels=TRUE, hjust = -0.3)+
    labs(title ="PCA_NonParametricCombatData")
  newfilename <- "mydata_NonParametricComBatCorrected.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(pcom, newfilepath)
  rlp<-RlaPlots( m[,-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_raw")
  rlp.pcom<-RlaPlots( pcom[-1], m[,1],saveplot=T, savetype= "jpeg",plotname = "RLAPlot_NonParametricComBat")
  p1<-plot(seq(along=corr), corr, xlab="variable",ylab="adj.r.square", main="rawData")
  p2<-plot(seq(along=corr.pc), corr.pc, xlab="variable",ylab="adj.r.square", main="NonParametricComBat-corrected")
  names(corr)<- names(m[-1])
  newfilename <- "rawdata_adjustedRsquare.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr, newfilepath)
  names(corr.pc)<- names(m[-1])
  newfilename <- "NonParametricComBatdata_adjRsquare.csv"
  newfilepath <- file.path(path_user, newfilename)
  write.csv(corr.pc, newfilepath)
  a1<- abs (corr [1:length(corr)])
  as1<-sum(a1)
  am1<-max(a1)
  a2<- abs(corr.pc[1:length(corr.pc)])
  as2<- sum(a2)
  am2<-max(a2)
  datm<-data.frame(Dataset=c("raw","NonParametricComBat"),adjRSq=c(am1,am2));
  newfilename <- "SCore_MaxdjRSq.csv"
  path_user <- dirname(file.path(tempdir(), newfilename))
  newfilepath <- file.path(path_user, newfilename)
  write.csv(datm, newfilepath)
  pm<-ggplot(data=datm, aes(x=reorder(Dataset, -adjRSq), y=adjRSq, fill=Dataset)) +
    geom_bar(stat="identity",width= 1)+
    theme_classic()
  pm<-pm + labs(x = "Dataset (raw and Model-corrected)")
  pm<-pm + labs(y = "Maximum Adjusted R-squared")
  pm<- pm + coord_flip()
  print(pca)
  print(pca.c)
  print(sc)
  print(sc.pcom)
  print(rlp)
  print(rlp.pcom)
  print(p1)
  print(p2)
  print(pm)
  Dataset<-adjRSq<-NULL
  dev.off()
}
